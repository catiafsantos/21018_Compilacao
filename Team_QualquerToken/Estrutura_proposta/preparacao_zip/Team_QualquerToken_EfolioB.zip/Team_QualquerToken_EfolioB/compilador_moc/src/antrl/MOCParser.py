# Generated from MOC.g4 by ANTLR 4.13.2
# encoding: utf-8
from antlr4 import *
from io import StringIO
import sys
if sys.version_info[1] > 5:
	from typing import TextIO
else:
	from typing.io import TextIO

def serializedATN():
    return [
        4,1,46,487,2,0,7,0,2,1,7,1,2,2,7,2,2,3,7,3,2,4,7,4,2,5,7,5,2,6,7,
        6,2,7,7,7,2,8,7,8,2,9,7,9,2,10,7,10,2,11,7,11,2,12,7,12,2,13,7,13,
        2,14,7,14,2,15,7,15,2,16,7,16,2,17,7,17,2,18,7,18,2,19,7,19,2,20,
        7,20,2,21,7,21,2,22,7,22,2,23,7,23,2,24,7,24,2,25,7,25,2,26,7,26,
        2,27,7,27,2,28,7,28,2,29,7,29,2,30,7,30,2,31,7,31,2,32,7,32,2,33,
        7,33,2,34,7,34,2,35,7,35,2,36,7,36,2,37,7,37,2,38,7,38,2,39,7,39,
        2,40,7,40,2,41,7,41,2,42,7,42,2,43,7,43,1,0,1,0,1,0,1,0,1,1,1,1,
        5,1,95,8,1,10,1,12,1,98,9,1,1,1,1,1,1,1,5,1,103,8,1,10,1,12,1,106,
        9,1,1,2,5,2,109,8,2,10,2,12,2,112,9,2,1,2,1,2,1,3,1,3,3,3,118,8,
        3,1,4,1,4,1,4,1,4,3,4,124,8,4,1,4,1,4,1,4,1,5,1,5,1,5,1,5,3,5,133,
        8,5,1,5,1,5,1,5,1,6,1,6,1,6,1,6,3,6,142,8,6,1,6,1,6,1,6,1,7,1,7,
        1,7,1,7,3,7,151,8,7,1,7,1,7,1,7,1,8,1,8,1,8,1,8,1,8,5,8,161,8,8,
        10,8,12,8,164,9,8,3,8,166,8,8,1,9,1,9,1,9,1,9,1,9,1,9,1,9,1,9,1,
        9,1,9,1,9,1,9,1,9,3,9,181,8,9,1,10,1,10,1,11,1,11,1,11,1,11,1,12,
        1,12,1,12,5,12,192,8,12,10,12,12,12,195,9,12,1,13,1,13,1,13,1,13,
        1,13,1,13,1,13,1,13,1,13,1,13,1,13,1,13,1,13,1,13,1,13,1,13,1,13,
        1,13,1,13,1,13,1,13,1,13,1,13,1,13,3,13,221,8,13,1,14,1,14,3,14,
        225,8,14,1,14,1,14,1,15,1,15,1,15,5,15,232,8,15,10,15,12,15,235,
        9,15,1,16,1,16,1,17,1,17,1,17,1,17,1,17,1,17,5,17,245,8,17,10,17,
        12,17,248,9,17,1,18,1,18,1,18,1,18,1,18,1,18,5,18,256,8,18,10,18,
        12,18,259,9,18,1,19,1,19,1,19,1,19,3,19,265,8,19,1,20,1,20,1,20,
        1,20,1,20,1,20,1,20,1,20,1,20,5,20,276,8,20,10,20,12,20,279,9,20,
        1,21,1,21,1,21,1,21,1,21,1,21,1,21,1,21,1,21,1,21,1,21,1,21,5,21,
        293,8,21,10,21,12,21,296,9,21,1,22,1,22,1,22,1,22,1,22,3,22,303,
        8,22,1,23,1,23,1,23,1,23,1,23,1,23,3,23,311,8,23,1,24,1,24,1,24,
        1,24,1,24,1,24,1,24,1,24,1,24,3,24,322,8,24,1,25,1,25,3,25,326,8,
        25,1,25,1,25,1,25,1,25,1,25,1,25,3,25,334,8,25,1,26,1,26,1,26,5,
        26,339,8,26,10,26,12,26,342,9,26,1,27,1,27,1,28,1,28,1,28,1,28,1,
        28,1,28,1,28,1,28,1,28,3,28,355,8,28,1,29,1,29,1,29,1,29,1,30,1,
        30,1,30,1,30,1,31,5,31,366,8,31,10,31,12,31,369,9,31,1,32,1,32,1,
        32,3,32,374,8,32,1,33,1,33,1,33,1,34,1,34,1,34,1,34,1,34,1,34,1,
        34,1,34,1,34,3,34,388,8,34,1,35,1,35,1,35,1,35,1,35,1,35,1,35,1,
        35,1,35,1,35,1,35,1,35,1,35,1,35,3,35,404,8,35,1,36,1,36,1,36,1,
        36,1,36,1,36,1,36,1,36,3,36,414,8,36,1,37,1,37,1,37,1,37,1,37,1,
        37,1,38,1,38,1,38,3,38,425,8,38,1,38,1,38,3,38,429,8,38,1,38,1,38,
        3,38,433,8,38,1,38,1,38,1,38,1,39,1,39,1,39,1,39,3,39,442,8,39,1,
        40,1,40,1,40,1,40,1,40,1,40,1,40,1,40,1,40,1,40,1,40,1,40,1,40,1,
        40,1,40,1,40,1,40,1,40,1,40,1,40,1,40,1,40,1,40,3,40,467,8,40,1,
        41,1,41,1,41,1,41,1,42,1,42,1,42,1,42,1,42,1,42,3,42,479,8,42,1,
        42,1,42,1,42,1,42,1,43,1,43,1,43,0,4,34,36,40,42,44,0,2,4,6,8,10,
        12,14,16,18,20,22,24,26,28,30,32,34,36,38,40,42,44,46,48,50,52,54,
        56,58,60,62,64,66,68,70,72,74,76,78,80,82,84,86,0,3,1,0,1,3,1,0,
        21,26,2,0,40,40,45,45,507,0,88,1,0,0,0,2,96,1,0,0,0,4,110,1,0,0,
        0,6,117,1,0,0,0,8,119,1,0,0,0,10,128,1,0,0,0,12,137,1,0,0,0,14,146,
        1,0,0,0,16,165,1,0,0,0,18,180,1,0,0,0,20,182,1,0,0,0,22,184,1,0,
        0,0,24,188,1,0,0,0,26,220,1,0,0,0,28,222,1,0,0,0,30,228,1,0,0,0,
        32,236,1,0,0,0,34,238,1,0,0,0,36,249,1,0,0,0,38,260,1,0,0,0,40,266,
        1,0,0,0,42,280,1,0,0,0,44,302,1,0,0,0,46,310,1,0,0,0,48,321,1,0,
        0,0,50,333,1,0,0,0,52,335,1,0,0,0,54,343,1,0,0,0,56,354,1,0,0,0,
        58,356,1,0,0,0,60,360,1,0,0,0,62,367,1,0,0,0,64,373,1,0,0,0,66,375,
        1,0,0,0,68,387,1,0,0,0,70,403,1,0,0,0,72,413,1,0,0,0,74,415,1,0,
        0,0,76,421,1,0,0,0,78,441,1,0,0,0,80,466,1,0,0,0,82,468,1,0,0,0,
        84,478,1,0,0,0,86,484,1,0,0,0,88,89,3,2,1,0,89,90,3,4,2,0,90,91,
        5,0,0,1,91,1,1,0,0,0,92,95,3,8,4,0,93,95,3,10,5,0,94,92,1,0,0,0,
        94,93,1,0,0,0,95,98,1,0,0,0,96,94,1,0,0,0,96,97,1,0,0,0,97,99,1,
        0,0,0,98,96,1,0,0,0,99,104,3,10,5,0,100,103,3,8,4,0,101,103,3,10,
        5,0,102,100,1,0,0,0,102,101,1,0,0,0,103,106,1,0,0,0,104,102,1,0,
        0,0,104,105,1,0,0,0,105,3,1,0,0,0,106,104,1,0,0,0,107,109,3,6,3,
        0,108,107,1,0,0,0,109,112,1,0,0,0,110,108,1,0,0,0,110,111,1,0,0,
        0,111,113,1,0,0,0,112,110,1,0,0,0,113,114,3,12,6,0,114,5,1,0,0,0,
        115,118,3,14,7,0,116,118,3,22,11,0,117,115,1,0,0,0,117,116,1,0,0,
        0,118,7,1,0,0,0,119,120,3,20,10,0,120,121,5,45,0,0,121,123,5,37,
        0,0,122,124,3,16,8,0,123,122,1,0,0,0,123,124,1,0,0,0,124,125,1,0,
        0,0,125,126,5,38,0,0,126,127,5,32,0,0,127,9,1,0,0,0,128,129,3,20,
        10,0,129,130,5,4,0,0,130,132,5,37,0,0,131,133,3,16,8,0,132,131,1,
        0,0,0,132,133,1,0,0,0,133,134,1,0,0,0,134,135,5,38,0,0,135,136,5,
        32,0,0,136,11,1,0,0,0,137,138,3,20,10,0,138,139,5,4,0,0,139,141,
        5,37,0,0,140,142,3,16,8,0,141,140,1,0,0,0,141,142,1,0,0,0,142,143,
        1,0,0,0,143,144,5,38,0,0,144,145,3,60,30,0,145,13,1,0,0,0,146,147,
        3,20,10,0,147,148,5,45,0,0,148,150,5,37,0,0,149,151,3,16,8,0,150,
        149,1,0,0,0,150,151,1,0,0,0,151,152,1,0,0,0,152,153,5,38,0,0,153,
        154,3,60,30,0,154,15,1,0,0,0,155,166,5,3,0,0,156,166,3,20,10,0,157,
        162,3,18,9,0,158,159,5,31,0,0,159,161,3,18,9,0,160,158,1,0,0,0,161,
        164,1,0,0,0,162,160,1,0,0,0,162,163,1,0,0,0,163,166,1,0,0,0,164,
        162,1,0,0,0,165,155,1,0,0,0,165,156,1,0,0,0,165,157,1,0,0,0,166,
        17,1,0,0,0,167,181,3,20,10,0,168,169,3,20,10,0,169,170,5,45,0,0,
        170,181,1,0,0,0,171,172,3,20,10,0,172,173,5,33,0,0,173,174,5,34,
        0,0,174,181,1,0,0,0,175,176,3,20,10,0,176,177,5,45,0,0,177,178,5,
        33,0,0,178,179,5,34,0,0,179,181,1,0,0,0,180,167,1,0,0,0,180,168,
        1,0,0,0,180,171,1,0,0,0,180,175,1,0,0,0,181,19,1,0,0,0,182,183,7,
        0,0,0,183,21,1,0,0,0,184,185,3,20,10,0,185,186,3,24,12,0,186,187,
        5,32,0,0,187,23,1,0,0,0,188,193,3,26,13,0,189,190,5,31,0,0,190,192,
        3,26,13,0,191,189,1,0,0,0,192,195,1,0,0,0,193,191,1,0,0,0,193,194,
        1,0,0,0,194,25,1,0,0,0,195,193,1,0,0,0,196,221,5,45,0,0,197,198,
        5,45,0,0,198,199,5,30,0,0,199,221,3,32,16,0,200,201,5,45,0,0,201,
        202,5,33,0,0,202,203,5,44,0,0,203,221,5,34,0,0,204,205,5,45,0,0,
        205,206,5,33,0,0,206,207,5,34,0,0,207,208,5,30,0,0,208,221,3,58,
        29,0,209,210,5,45,0,0,210,211,5,33,0,0,211,212,5,34,0,0,212,213,
        5,30,0,0,213,221,3,28,14,0,214,215,5,45,0,0,215,216,5,33,0,0,216,
        217,5,44,0,0,217,218,5,34,0,0,218,219,5,30,0,0,219,221,3,28,14,0,
        220,196,1,0,0,0,220,197,1,0,0,0,220,200,1,0,0,0,220,204,1,0,0,0,
        220,209,1,0,0,0,220,214,1,0,0,0,221,27,1,0,0,0,222,224,5,35,0,0,
        223,225,3,30,15,0,224,223,1,0,0,0,224,225,1,0,0,0,225,226,1,0,0,
        0,226,227,5,36,0,0,227,29,1,0,0,0,228,233,3,32,16,0,229,230,5,31,
        0,0,230,232,3,32,16,0,231,229,1,0,0,0,232,235,1,0,0,0,233,231,1,
        0,0,0,233,234,1,0,0,0,234,31,1,0,0,0,235,233,1,0,0,0,236,237,3,34,
        17,0,237,33,1,0,0,0,238,239,6,17,-1,0,239,240,3,36,18,0,240,246,
        1,0,0,0,241,242,10,2,0,0,242,243,5,28,0,0,243,245,3,36,18,0,244,
        241,1,0,0,0,245,248,1,0,0,0,246,244,1,0,0,0,246,247,1,0,0,0,247,
        35,1,0,0,0,248,246,1,0,0,0,249,250,6,18,-1,0,250,251,3,38,19,0,251,
        257,1,0,0,0,252,253,10,2,0,0,253,254,5,27,0,0,254,256,3,38,19,0,
        255,252,1,0,0,0,256,259,1,0,0,0,257,255,1,0,0,0,257,258,1,0,0,0,
        258,37,1,0,0,0,259,257,1,0,0,0,260,264,3,40,20,0,261,262,3,54,27,
        0,262,263,3,40,20,0,263,265,1,0,0,0,264,261,1,0,0,0,264,265,1,0,
        0,0,265,39,1,0,0,0,266,267,6,20,-1,0,267,268,3,42,21,0,268,277,1,
        0,0,0,269,270,10,3,0,0,270,271,5,16,0,0,271,276,3,42,21,0,272,273,
        10,2,0,0,273,274,5,17,0,0,274,276,3,42,21,0,275,269,1,0,0,0,275,
        272,1,0,0,0,276,279,1,0,0,0,277,275,1,0,0,0,277,278,1,0,0,0,278,
        41,1,0,0,0,279,277,1,0,0,0,280,281,6,21,-1,0,281,282,3,44,22,0,282,
        294,1,0,0,0,283,284,10,4,0,0,284,285,5,18,0,0,285,293,3,44,22,0,
        286,287,10,3,0,0,287,288,5,19,0,0,288,293,3,44,22,0,289,290,10,2,
        0,0,290,291,5,20,0,0,291,293,3,44,22,0,292,283,1,0,0,0,292,286,1,
        0,0,0,292,289,1,0,0,0,293,296,1,0,0,0,294,292,1,0,0,0,294,295,1,
        0,0,0,295,43,1,0,0,0,296,294,1,0,0,0,297,298,5,29,0,0,298,303,3,
        44,22,0,299,300,5,17,0,0,300,303,3,44,22,0,301,303,3,46,23,0,302,
        297,1,0,0,0,302,299,1,0,0,0,302,301,1,0,0,0,303,45,1,0,0,0,304,305,
        5,37,0,0,305,306,3,20,10,0,306,307,5,38,0,0,307,308,3,46,23,0,308,
        311,1,0,0,0,309,311,3,48,24,0,310,304,1,0,0,0,310,309,1,0,0,0,311,
        47,1,0,0,0,312,313,5,37,0,0,313,314,3,32,16,0,314,315,5,38,0,0,315,
        322,1,0,0,0,316,322,3,56,28,0,317,322,5,44,0,0,318,322,5,43,0,0,
        319,320,5,45,0,0,320,322,3,50,25,0,321,312,1,0,0,0,321,316,1,0,0,
        0,321,317,1,0,0,0,321,318,1,0,0,0,321,319,1,0,0,0,322,49,1,0,0,0,
        323,325,5,37,0,0,324,326,3,52,26,0,325,324,1,0,0,0,325,326,1,0,0,
        0,326,327,1,0,0,0,327,334,5,38,0,0,328,329,5,33,0,0,329,330,3,32,
        16,0,330,331,5,34,0,0,331,334,1,0,0,0,332,334,1,0,0,0,333,323,1,
        0,0,0,333,328,1,0,0,0,333,332,1,0,0,0,334,51,1,0,0,0,335,340,3,32,
        16,0,336,337,5,31,0,0,337,339,3,32,16,0,338,336,1,0,0,0,339,342,
        1,0,0,0,340,338,1,0,0,0,340,341,1,0,0,0,341,53,1,0,0,0,342,340,1,
        0,0,0,343,344,7,1,0,0,344,55,1,0,0,0,345,346,5,5,0,0,346,347,5,37,
        0,0,347,355,5,38,0,0,348,349,5,6,0,0,349,350,5,37,0,0,350,355,5,
        38,0,0,351,352,5,7,0,0,352,353,5,37,0,0,353,355,5,38,0,0,354,345,
        1,0,0,0,354,348,1,0,0,0,354,351,1,0,0,0,355,57,1,0,0,0,356,357,5,
        7,0,0,357,358,5,37,0,0,358,359,5,38,0,0,359,59,1,0,0,0,360,361,5,
        35,0,0,361,362,3,62,31,0,362,363,5,36,0,0,363,61,1,0,0,0,364,366,
        3,64,32,0,365,364,1,0,0,0,366,369,1,0,0,0,367,365,1,0,0,0,367,368,
        1,0,0,0,368,63,1,0,0,0,369,367,1,0,0,0,370,374,3,68,34,0,371,374,
        3,70,35,0,372,374,3,72,36,0,373,370,1,0,0,0,373,371,1,0,0,0,373,
        372,1,0,0,0,374,65,1,0,0,0,375,376,3,32,16,0,376,377,5,32,0,0,377,
        67,1,0,0,0,378,379,5,12,0,0,379,380,5,37,0,0,380,381,3,32,16,0,381,
        382,5,38,0,0,382,383,3,60,30,0,383,384,5,13,0,0,384,385,3,68,34,
        0,385,388,1,0,0,0,386,388,3,60,30,0,387,378,1,0,0,0,387,386,1,0,
        0,0,388,69,1,0,0,0,389,390,5,12,0,0,390,391,5,37,0,0,391,392,3,32,
        16,0,392,393,5,38,0,0,393,394,3,60,30,0,394,404,1,0,0,0,395,396,
        5,12,0,0,396,397,5,37,0,0,397,398,3,32,16,0,398,399,5,38,0,0,399,
        400,3,60,30,0,400,401,5,13,0,0,401,402,3,70,35,0,402,404,1,0,0,0,
        403,389,1,0,0,0,403,395,1,0,0,0,404,71,1,0,0,0,405,414,3,60,30,0,
        406,414,3,22,11,0,407,414,3,74,37,0,408,414,3,76,38,0,409,414,3,
        80,40,0,410,414,3,82,41,0,411,414,3,84,42,0,412,414,3,66,33,0,413,
        405,1,0,0,0,413,406,1,0,0,0,413,407,1,0,0,0,413,408,1,0,0,0,413,
        409,1,0,0,0,413,410,1,0,0,0,413,411,1,0,0,0,413,412,1,0,0,0,414,
        73,1,0,0,0,415,416,5,14,0,0,416,417,5,37,0,0,417,418,3,32,16,0,418,
        419,5,38,0,0,419,420,3,60,30,0,420,75,1,0,0,0,421,422,5,15,0,0,422,
        424,5,37,0,0,423,425,3,78,39,0,424,423,1,0,0,0,424,425,1,0,0,0,425,
        426,1,0,0,0,426,428,5,32,0,0,427,429,3,32,16,0,428,427,1,0,0,0,428,
        429,1,0,0,0,429,430,1,0,0,0,430,432,5,32,0,0,431,433,3,78,39,0,432,
        431,1,0,0,0,432,433,1,0,0,0,433,434,1,0,0,0,434,435,5,38,0,0,435,
        436,3,60,30,0,436,77,1,0,0,0,437,438,5,45,0,0,438,439,5,30,0,0,439,
        442,3,32,16,0,440,442,3,32,16,0,441,437,1,0,0,0,441,440,1,0,0,0,
        442,79,1,0,0,0,443,444,5,8,0,0,444,445,5,37,0,0,445,446,3,32,16,
        0,446,447,5,38,0,0,447,448,5,32,0,0,448,467,1,0,0,0,449,450,5,9,
        0,0,450,451,5,37,0,0,451,452,3,32,16,0,452,453,5,38,0,0,453,454,
        5,32,0,0,454,467,1,0,0,0,455,456,5,10,0,0,456,457,5,37,0,0,457,458,
        5,45,0,0,458,459,5,38,0,0,459,467,5,32,0,0,460,461,5,11,0,0,461,
        462,5,37,0,0,462,463,3,86,43,0,463,464,5,38,0,0,464,465,5,32,0,0,
        465,467,1,0,0,0,466,443,1,0,0,0,466,449,1,0,0,0,466,455,1,0,0,0,
        466,460,1,0,0,0,467,81,1,0,0,0,468,469,5,39,0,0,469,470,3,32,16,
        0,470,471,5,32,0,0,471,83,1,0,0,0,472,479,5,45,0,0,473,474,5,45,
        0,0,474,475,5,33,0,0,475,476,3,32,16,0,476,477,5,34,0,0,477,479,
        1,0,0,0,478,472,1,0,0,0,478,473,1,0,0,0,479,480,1,0,0,0,480,481,
        5,30,0,0,481,482,3,32,16,0,482,483,5,32,0,0,483,85,1,0,0,0,484,485,
        7,2,0,0,485,87,1,0,0,0,42,94,96,102,104,110,117,123,132,141,150,
        162,165,180,193,220,224,233,246,257,264,275,277,292,294,302,310,
        321,325,333,340,354,367,373,387,403,413,424,428,432,441,466,478
    ]

class MOCParser ( Parser ):

    grammarFileName = "MOC.g4"

    atn = ATNDeserializer().deserialize(serializedATN())

    decisionsToDFA = [ DFA(ds, i) for i, ds in enumerate(atn.decisionToState) ]

    sharedContextCache = PredictionContextCache()

    literalNames = [ "<INVALID>", "'int'", "'double'", "'void'", "'main'", 
                     "'read'", "'readc'", "'reads'", "'write'", "'writec'", 
                     "'writev'", "'writes'", "'if'", "'else'", "'while'", 
                     "'for'", "'+'", "'-'", "'*'", "'/'", "'%'", "'<'", 
                     "'<='", "'>'", "'>='", "'=='", "'!='", "'&&'", "'||'", 
                     "'!'", "'='", "','", "';'", "'['", "']'", "'{'", "'}'", 
                     "'('", "')'", "'return'" ]

    symbolicNames = [ "<INVALID>", "INT", "DOUBLE", "VOID", "MAIN", "READ", 
                      "READC", "READS", "WRITE", "WRITEC", "WRITEV", "WRITES", 
                      "IF", "ELSE", "WHILE", "FOR", "MAIS", "MENOS", "MULT", 
                      "DIV", "MODULO", "MENOR", "MENORIGUAL", "MAIOR", "MAIORIGUAL", 
                      "IGUAL", "DIFERENTE", "E_LOGICO", "OU_LOGICO", "NAO", 
                      "ATRIBUICAO", "VIRGULA", "PONTOVIRG", "ABRECOLCH", 
                      "FECHACOLCH", "ABRECHAVES", "FECHACHAVES", "ABREPAR", 
                      "FECHAPAR", "RETURN", "STRINGLITERAL", "COMENTARIO_BLOCK", 
                      "COMENTARIO_LINE", "NUM_REAL", "NUMERO", "IDENTIFICADOR", 
                      "ESPACO" ]

    RULE_programa = 0
    RULE_prototipos = 1
    RULE_corpo = 2
    RULE_unidade = 3
    RULE_prototipo = 4
    RULE_prototipoPrincipal = 5
    RULE_funcaoPrincipal = 6
    RULE_funcao = 7
    RULE_parametros = 8
    RULE_parametro = 9
    RULE_tipo = 10
    RULE_declaracao = 11
    RULE_listaVariaveis = 12
    RULE_variavel = 13
    RULE_blocoArray = 14
    RULE_listaValores = 15
    RULE_expressao = 16
    RULE_expressaoOr = 17
    RULE_expressaoAnd = 18
    RULE_expressaoEquality = 19
    RULE_expressaoAdd = 20
    RULE_expressaoMul = 21
    RULE_expressaoUnaria = 22
    RULE_castExpr = 23
    RULE_primary = 24
    RULE_primaryRest = 25
    RULE_argumentos = 26
    RULE_opRelacional = 27
    RULE_chamadaFuncao = 28
    RULE_chamadaReads = 29
    RULE_bloco = 30
    RULE_instrucoes = 31
    RULE_instrucao = 32
    RULE_instrucaoExpressao = 33
    RULE_instrucaoEmparelhada = 34
    RULE_instrucaoPorEmparelhar = 35
    RULE_outraInstrucao = 36
    RULE_instrucaoWhile = 37
    RULE_instrucaoFor = 38
    RULE_expressaoOuAtribuicao = 39
    RULE_instrucaoEscrita = 40
    RULE_instrucaoReturn = 41
    RULE_instrucaoAtribuicao = 42
    RULE_argumentoString = 43

    ruleNames =  [ "programa", "prototipos", "corpo", "unidade", "prototipo", 
                   "prototipoPrincipal", "funcaoPrincipal", "funcao", "parametros", 
                   "parametro", "tipo", "declaracao", "listaVariaveis", 
                   "variavel", "blocoArray", "listaValores", "expressao", 
                   "expressaoOr", "expressaoAnd", "expressaoEquality", "expressaoAdd", 
                   "expressaoMul", "expressaoUnaria", "castExpr", "primary", 
                   "primaryRest", "argumentos", "opRelacional", "chamadaFuncao", 
                   "chamadaReads", "bloco", "instrucoes", "instrucao", "instrucaoExpressao", 
                   "instrucaoEmparelhada", "instrucaoPorEmparelhar", "outraInstrucao", 
                   "instrucaoWhile", "instrucaoFor", "expressaoOuAtribuicao", 
                   "instrucaoEscrita", "instrucaoReturn", "instrucaoAtribuicao", 
                   "argumentoString" ]

    EOF = Token.EOF
    INT=1
    DOUBLE=2
    VOID=3
    MAIN=4
    READ=5
    READC=6
    READS=7
    WRITE=8
    WRITEC=9
    WRITEV=10
    WRITES=11
    IF=12
    ELSE=13
    WHILE=14
    FOR=15
    MAIS=16
    MENOS=17
    MULT=18
    DIV=19
    MODULO=20
    MENOR=21
    MENORIGUAL=22
    MAIOR=23
    MAIORIGUAL=24
    IGUAL=25
    DIFERENTE=26
    E_LOGICO=27
    OU_LOGICO=28
    NAO=29
    ATRIBUICAO=30
    VIRGULA=31
    PONTOVIRG=32
    ABRECOLCH=33
    FECHACOLCH=34
    ABRECHAVES=35
    FECHACHAVES=36
    ABREPAR=37
    FECHAPAR=38
    RETURN=39
    STRINGLITERAL=40
    COMENTARIO_BLOCK=41
    COMENTARIO_LINE=42
    NUM_REAL=43
    NUMERO=44
    IDENTIFICADOR=45
    ESPACO=46

    def __init__(self, input:TokenStream, output:TextIO = sys.stdout):
        super().__init__(input, output)
        self.checkVersion("4.13.2")
        self._interp = ParserATNSimulator(self, self.atn, self.decisionsToDFA, self.sharedContextCache)
        self._predicates = None




    class ProgramaContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def prototipos(self):
            return self.getTypedRuleContext(MOCParser.PrototiposContext,0)


        def corpo(self):
            return self.getTypedRuleContext(MOCParser.CorpoContext,0)


        def EOF(self):
            return self.getToken(MOCParser.EOF, 0)

        def getRuleIndex(self):
            return MOCParser.RULE_programa

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterPrograma" ):
                listener.enterPrograma(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitPrograma" ):
                listener.exitPrograma(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitPrograma" ):
                return visitor.visitPrograma(self)
            else:
                return visitor.visitChildren(self)




    def programa(self):

        localctx = MOCParser.ProgramaContext(self, self._ctx, self.state)
        self.enterRule(localctx, 0, self.RULE_programa)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 88
            self.prototipos()
            self.state = 89
            self.corpo()
            self.state = 90
            self.match(MOCParser.EOF)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class PrototiposContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def prototipoPrincipal(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(MOCParser.PrototipoPrincipalContext)
            else:
                return self.getTypedRuleContext(MOCParser.PrototipoPrincipalContext,i)


        def prototipo(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(MOCParser.PrototipoContext)
            else:
                return self.getTypedRuleContext(MOCParser.PrototipoContext,i)


        def getRuleIndex(self):
            return MOCParser.RULE_prototipos

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterPrototipos" ):
                listener.enterPrototipos(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitPrototipos" ):
                listener.exitPrototipos(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitPrototipos" ):
                return visitor.visitPrototipos(self)
            else:
                return visitor.visitChildren(self)




    def prototipos(self):

        localctx = MOCParser.PrototiposContext(self, self._ctx, self.state)
        self.enterRule(localctx, 2, self.RULE_prototipos)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 96
            self._errHandler.sync(self)
            _alt = self._interp.adaptivePredict(self._input,1,self._ctx)
            while _alt!=2 and _alt!=ATN.INVALID_ALT_NUMBER:
                if _alt==1:
                    self.state = 94
                    self._errHandler.sync(self)
                    la_ = self._interp.adaptivePredict(self._input,0,self._ctx)
                    if la_ == 1:
                        self.state = 92
                        self.prototipo()
                        pass

                    elif la_ == 2:
                        self.state = 93
                        self.prototipoPrincipal()
                        pass

             
                self.state = 98
                self._errHandler.sync(self)
                _alt = self._interp.adaptivePredict(self._input,1,self._ctx)

            self.state = 99
            self.prototipoPrincipal()
            self.state = 104
            self._errHandler.sync(self)
            _alt = self._interp.adaptivePredict(self._input,3,self._ctx)
            while _alt!=2 and _alt!=ATN.INVALID_ALT_NUMBER:
                if _alt==1:
                    self.state = 102
                    self._errHandler.sync(self)
                    la_ = self._interp.adaptivePredict(self._input,2,self._ctx)
                    if la_ == 1:
                        self.state = 100
                        self.prototipo()
                        pass

                    elif la_ == 2:
                        self.state = 101
                        self.prototipoPrincipal()
                        pass

             
                self.state = 106
                self._errHandler.sync(self)
                _alt = self._interp.adaptivePredict(self._input,3,self._ctx)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class CorpoContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def funcaoPrincipal(self):
            return self.getTypedRuleContext(MOCParser.FuncaoPrincipalContext,0)


        def unidade(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(MOCParser.UnidadeContext)
            else:
                return self.getTypedRuleContext(MOCParser.UnidadeContext,i)


        def getRuleIndex(self):
            return MOCParser.RULE_corpo

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterCorpo" ):
                listener.enterCorpo(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitCorpo" ):
                listener.exitCorpo(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitCorpo" ):
                return visitor.visitCorpo(self)
            else:
                return visitor.visitChildren(self)




    def corpo(self):

        localctx = MOCParser.CorpoContext(self, self._ctx, self.state)
        self.enterRule(localctx, 4, self.RULE_corpo)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 110
            self._errHandler.sync(self)
            _alt = self._interp.adaptivePredict(self._input,4,self._ctx)
            while _alt!=2 and _alt!=ATN.INVALID_ALT_NUMBER:
                if _alt==1:
                    self.state = 107
                    self.unidade() 
                self.state = 112
                self._errHandler.sync(self)
                _alt = self._interp.adaptivePredict(self._input,4,self._ctx)

            self.state = 113
            self.funcaoPrincipal()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class UnidadeContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def funcao(self):
            return self.getTypedRuleContext(MOCParser.FuncaoContext,0)


        def declaracao(self):
            return self.getTypedRuleContext(MOCParser.DeclaracaoContext,0)


        def getRuleIndex(self):
            return MOCParser.RULE_unidade

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterUnidade" ):
                listener.enterUnidade(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitUnidade" ):
                listener.exitUnidade(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitUnidade" ):
                return visitor.visitUnidade(self)
            else:
                return visitor.visitChildren(self)




    def unidade(self):

        localctx = MOCParser.UnidadeContext(self, self._ctx, self.state)
        self.enterRule(localctx, 6, self.RULE_unidade)
        try:
            self.state = 117
            self._errHandler.sync(self)
            la_ = self._interp.adaptivePredict(self._input,5,self._ctx)
            if la_ == 1:
                self.enterOuterAlt(localctx, 1)
                self.state = 115
                self.funcao()
                pass

            elif la_ == 2:
                self.enterOuterAlt(localctx, 2)
                self.state = 116
                self.declaracao()
                pass


        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class PrototipoContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def tipo(self):
            return self.getTypedRuleContext(MOCParser.TipoContext,0)


        def IDENTIFICADOR(self):
            return self.getToken(MOCParser.IDENTIFICADOR, 0)

        def ABREPAR(self):
            return self.getToken(MOCParser.ABREPAR, 0)

        def FECHAPAR(self):
            return self.getToken(MOCParser.FECHAPAR, 0)

        def PONTOVIRG(self):
            return self.getToken(MOCParser.PONTOVIRG, 0)

        def parametros(self):
            return self.getTypedRuleContext(MOCParser.ParametrosContext,0)


        def getRuleIndex(self):
            return MOCParser.RULE_prototipo

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterPrototipo" ):
                listener.enterPrototipo(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitPrototipo" ):
                listener.exitPrototipo(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitPrototipo" ):
                return visitor.visitPrototipo(self)
            else:
                return visitor.visitChildren(self)




    def prototipo(self):

        localctx = MOCParser.PrototipoContext(self, self._ctx, self.state)
        self.enterRule(localctx, 8, self.RULE_prototipo)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 119
            self.tipo()
            self.state = 120
            self.match(MOCParser.IDENTIFICADOR)
            self.state = 121
            self.match(MOCParser.ABREPAR)
            self.state = 123
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if (((_la) & ~0x3f) == 0 and ((1 << _la) & 14) != 0):
                self.state = 122
                self.parametros()


            self.state = 125
            self.match(MOCParser.FECHAPAR)
            self.state = 126
            self.match(MOCParser.PONTOVIRG)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class PrototipoPrincipalContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def tipo(self):
            return self.getTypedRuleContext(MOCParser.TipoContext,0)


        def MAIN(self):
            return self.getToken(MOCParser.MAIN, 0)

        def ABREPAR(self):
            return self.getToken(MOCParser.ABREPAR, 0)

        def FECHAPAR(self):
            return self.getToken(MOCParser.FECHAPAR, 0)

        def PONTOVIRG(self):
            return self.getToken(MOCParser.PONTOVIRG, 0)

        def parametros(self):
            return self.getTypedRuleContext(MOCParser.ParametrosContext,0)


        def getRuleIndex(self):
            return MOCParser.RULE_prototipoPrincipal

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterPrototipoPrincipal" ):
                listener.enterPrototipoPrincipal(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitPrototipoPrincipal" ):
                listener.exitPrototipoPrincipal(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitPrototipoPrincipal" ):
                return visitor.visitPrototipoPrincipal(self)
            else:
                return visitor.visitChildren(self)




    def prototipoPrincipal(self):

        localctx = MOCParser.PrototipoPrincipalContext(self, self._ctx, self.state)
        self.enterRule(localctx, 10, self.RULE_prototipoPrincipal)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 128
            self.tipo()
            self.state = 129
            self.match(MOCParser.MAIN)
            self.state = 130
            self.match(MOCParser.ABREPAR)
            self.state = 132
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if (((_la) & ~0x3f) == 0 and ((1 << _la) & 14) != 0):
                self.state = 131
                self.parametros()


            self.state = 134
            self.match(MOCParser.FECHAPAR)
            self.state = 135
            self.match(MOCParser.PONTOVIRG)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class FuncaoPrincipalContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def tipo(self):
            return self.getTypedRuleContext(MOCParser.TipoContext,0)


        def MAIN(self):
            return self.getToken(MOCParser.MAIN, 0)

        def ABREPAR(self):
            return self.getToken(MOCParser.ABREPAR, 0)

        def FECHAPAR(self):
            return self.getToken(MOCParser.FECHAPAR, 0)

        def bloco(self):
            return self.getTypedRuleContext(MOCParser.BlocoContext,0)


        def parametros(self):
            return self.getTypedRuleContext(MOCParser.ParametrosContext,0)


        def getRuleIndex(self):
            return MOCParser.RULE_funcaoPrincipal

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterFuncaoPrincipal" ):
                listener.enterFuncaoPrincipal(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitFuncaoPrincipal" ):
                listener.exitFuncaoPrincipal(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitFuncaoPrincipal" ):
                return visitor.visitFuncaoPrincipal(self)
            else:
                return visitor.visitChildren(self)




    def funcaoPrincipal(self):

        localctx = MOCParser.FuncaoPrincipalContext(self, self._ctx, self.state)
        self.enterRule(localctx, 12, self.RULE_funcaoPrincipal)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 137
            self.tipo()
            self.state = 138
            self.match(MOCParser.MAIN)
            self.state = 139
            self.match(MOCParser.ABREPAR)
            self.state = 141
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if (((_la) & ~0x3f) == 0 and ((1 << _la) & 14) != 0):
                self.state = 140
                self.parametros()


            self.state = 143
            self.match(MOCParser.FECHAPAR)
            self.state = 144
            self.bloco()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class FuncaoContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def tipo(self):
            return self.getTypedRuleContext(MOCParser.TipoContext,0)


        def IDENTIFICADOR(self):
            return self.getToken(MOCParser.IDENTIFICADOR, 0)

        def ABREPAR(self):
            return self.getToken(MOCParser.ABREPAR, 0)

        def FECHAPAR(self):
            return self.getToken(MOCParser.FECHAPAR, 0)

        def bloco(self):
            return self.getTypedRuleContext(MOCParser.BlocoContext,0)


        def parametros(self):
            return self.getTypedRuleContext(MOCParser.ParametrosContext,0)


        def getRuleIndex(self):
            return MOCParser.RULE_funcao

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterFuncao" ):
                listener.enterFuncao(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitFuncao" ):
                listener.exitFuncao(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitFuncao" ):
                return visitor.visitFuncao(self)
            else:
                return visitor.visitChildren(self)




    def funcao(self):

        localctx = MOCParser.FuncaoContext(self, self._ctx, self.state)
        self.enterRule(localctx, 14, self.RULE_funcao)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 146
            self.tipo()
            self.state = 147
            self.match(MOCParser.IDENTIFICADOR)
            self.state = 148
            self.match(MOCParser.ABREPAR)
            self.state = 150
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if (((_la) & ~0x3f) == 0 and ((1 << _la) & 14) != 0):
                self.state = 149
                self.parametros()


            self.state = 152
            self.match(MOCParser.FECHAPAR)
            self.state = 153
            self.bloco()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class ParametrosContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def VOID(self):
            return self.getToken(MOCParser.VOID, 0)

        def tipo(self):
            return self.getTypedRuleContext(MOCParser.TipoContext,0)


        def parametro(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(MOCParser.ParametroContext)
            else:
                return self.getTypedRuleContext(MOCParser.ParametroContext,i)


        def VIRGULA(self, i:int=None):
            if i is None:
                return self.getTokens(MOCParser.VIRGULA)
            else:
                return self.getToken(MOCParser.VIRGULA, i)

        def getRuleIndex(self):
            return MOCParser.RULE_parametros

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterParametros" ):
                listener.enterParametros(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitParametros" ):
                listener.exitParametros(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitParametros" ):
                return visitor.visitParametros(self)
            else:
                return visitor.visitChildren(self)




    def parametros(self):

        localctx = MOCParser.ParametrosContext(self, self._ctx, self.state)
        self.enterRule(localctx, 16, self.RULE_parametros)
        self._la = 0 # Token type
        try:
            self.state = 165
            self._errHandler.sync(self)
            la_ = self._interp.adaptivePredict(self._input,11,self._ctx)
            if la_ == 1:
                self.enterOuterAlt(localctx, 1)
                self.state = 155
                self.match(MOCParser.VOID)
                pass

            elif la_ == 2:
                self.enterOuterAlt(localctx, 2)
                self.state = 156
                self.tipo()
                pass

            elif la_ == 3:
                self.enterOuterAlt(localctx, 3)
                self.state = 157
                self.parametro()
                self.state = 162
                self._errHandler.sync(self)
                _la = self._input.LA(1)
                while _la==31:
                    self.state = 158
                    self.match(MOCParser.VIRGULA)
                    self.state = 159
                    self.parametro()
                    self.state = 164
                    self._errHandler.sync(self)
                    _la = self._input.LA(1)

                pass


        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class ParametroContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def tipo(self):
            return self.getTypedRuleContext(MOCParser.TipoContext,0)


        def IDENTIFICADOR(self):
            return self.getToken(MOCParser.IDENTIFICADOR, 0)

        def ABRECOLCH(self):
            return self.getToken(MOCParser.ABRECOLCH, 0)

        def FECHACOLCH(self):
            return self.getToken(MOCParser.FECHACOLCH, 0)

        def getRuleIndex(self):
            return MOCParser.RULE_parametro

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterParametro" ):
                listener.enterParametro(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitParametro" ):
                listener.exitParametro(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitParametro" ):
                return visitor.visitParametro(self)
            else:
                return visitor.visitChildren(self)




    def parametro(self):

        localctx = MOCParser.ParametroContext(self, self._ctx, self.state)
        self.enterRule(localctx, 18, self.RULE_parametro)
        try:
            self.state = 180
            self._errHandler.sync(self)
            la_ = self._interp.adaptivePredict(self._input,12,self._ctx)
            if la_ == 1:
                self.enterOuterAlt(localctx, 1)
                self.state = 167
                self.tipo()
                pass

            elif la_ == 2:
                self.enterOuterAlt(localctx, 2)
                self.state = 168
                self.tipo()
                self.state = 169
                self.match(MOCParser.IDENTIFICADOR)
                pass

            elif la_ == 3:
                self.enterOuterAlt(localctx, 3)
                self.state = 171
                self.tipo()
                self.state = 172
                self.match(MOCParser.ABRECOLCH)
                self.state = 173
                self.match(MOCParser.FECHACOLCH)
                pass

            elif la_ == 4:
                self.enterOuterAlt(localctx, 4)
                self.state = 175
                self.tipo()
                self.state = 176
                self.match(MOCParser.IDENTIFICADOR)
                self.state = 177
                self.match(MOCParser.ABRECOLCH)
                self.state = 178
                self.match(MOCParser.FECHACOLCH)
                pass


        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class TipoContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def INT(self):
            return self.getToken(MOCParser.INT, 0)

        def DOUBLE(self):
            return self.getToken(MOCParser.DOUBLE, 0)

        def VOID(self):
            return self.getToken(MOCParser.VOID, 0)

        def getRuleIndex(self):
            return MOCParser.RULE_tipo

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterTipo" ):
                listener.enterTipo(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitTipo" ):
                listener.exitTipo(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitTipo" ):
                return visitor.visitTipo(self)
            else:
                return visitor.visitChildren(self)




    def tipo(self):

        localctx = MOCParser.TipoContext(self, self._ctx, self.state)
        self.enterRule(localctx, 20, self.RULE_tipo)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 182
            _la = self._input.LA(1)
            if not((((_la) & ~0x3f) == 0 and ((1 << _la) & 14) != 0)):
                self._errHandler.recoverInline(self)
            else:
                self._errHandler.reportMatch(self)
                self.consume()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class DeclaracaoContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def tipo(self):
            return self.getTypedRuleContext(MOCParser.TipoContext,0)


        def listaVariaveis(self):
            return self.getTypedRuleContext(MOCParser.ListaVariaveisContext,0)


        def PONTOVIRG(self):
            return self.getToken(MOCParser.PONTOVIRG, 0)

        def getRuleIndex(self):
            return MOCParser.RULE_declaracao

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterDeclaracao" ):
                listener.enterDeclaracao(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitDeclaracao" ):
                listener.exitDeclaracao(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitDeclaracao" ):
                return visitor.visitDeclaracao(self)
            else:
                return visitor.visitChildren(self)




    def declaracao(self):

        localctx = MOCParser.DeclaracaoContext(self, self._ctx, self.state)
        self.enterRule(localctx, 22, self.RULE_declaracao)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 184
            self.tipo()
            self.state = 185
            self.listaVariaveis()
            self.state = 186
            self.match(MOCParser.PONTOVIRG)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class ListaVariaveisContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def variavel(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(MOCParser.VariavelContext)
            else:
                return self.getTypedRuleContext(MOCParser.VariavelContext,i)


        def VIRGULA(self, i:int=None):
            if i is None:
                return self.getTokens(MOCParser.VIRGULA)
            else:
                return self.getToken(MOCParser.VIRGULA, i)

        def getRuleIndex(self):
            return MOCParser.RULE_listaVariaveis

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterListaVariaveis" ):
                listener.enterListaVariaveis(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitListaVariaveis" ):
                listener.exitListaVariaveis(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitListaVariaveis" ):
                return visitor.visitListaVariaveis(self)
            else:
                return visitor.visitChildren(self)




    def listaVariaveis(self):

        localctx = MOCParser.ListaVariaveisContext(self, self._ctx, self.state)
        self.enterRule(localctx, 24, self.RULE_listaVariaveis)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 188
            self.variavel()
            self.state = 193
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while _la==31:
                self.state = 189
                self.match(MOCParser.VIRGULA)
                self.state = 190
                self.variavel()
                self.state = 195
                self._errHandler.sync(self)
                _la = self._input.LA(1)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class VariavelContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def IDENTIFICADOR(self):
            return self.getToken(MOCParser.IDENTIFICADOR, 0)

        def ATRIBUICAO(self):
            return self.getToken(MOCParser.ATRIBUICAO, 0)

        def expressao(self):
            return self.getTypedRuleContext(MOCParser.ExpressaoContext,0)


        def ABRECOLCH(self):
            return self.getToken(MOCParser.ABRECOLCH, 0)

        def NUMERO(self):
            return self.getToken(MOCParser.NUMERO, 0)

        def FECHACOLCH(self):
            return self.getToken(MOCParser.FECHACOLCH, 0)

        def chamadaReads(self):
            return self.getTypedRuleContext(MOCParser.ChamadaReadsContext,0)


        def blocoArray(self):
            return self.getTypedRuleContext(MOCParser.BlocoArrayContext,0)


        def getRuleIndex(self):
            return MOCParser.RULE_variavel

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterVariavel" ):
                listener.enterVariavel(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitVariavel" ):
                listener.exitVariavel(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitVariavel" ):
                return visitor.visitVariavel(self)
            else:
                return visitor.visitChildren(self)




    def variavel(self):

        localctx = MOCParser.VariavelContext(self, self._ctx, self.state)
        self.enterRule(localctx, 26, self.RULE_variavel)
        try:
            self.state = 220
            self._errHandler.sync(self)
            la_ = self._interp.adaptivePredict(self._input,14,self._ctx)
            if la_ == 1:
                self.enterOuterAlt(localctx, 1)
                self.state = 196
                self.match(MOCParser.IDENTIFICADOR)
                pass

            elif la_ == 2:
                self.enterOuterAlt(localctx, 2)
                self.state = 197
                self.match(MOCParser.IDENTIFICADOR)
                self.state = 198
                self.match(MOCParser.ATRIBUICAO)
                self.state = 199
                self.expressao()
                pass

            elif la_ == 3:
                self.enterOuterAlt(localctx, 3)
                self.state = 200
                self.match(MOCParser.IDENTIFICADOR)
                self.state = 201
                self.match(MOCParser.ABRECOLCH)
                self.state = 202
                self.match(MOCParser.NUMERO)
                self.state = 203
                self.match(MOCParser.FECHACOLCH)
                pass

            elif la_ == 4:
                self.enterOuterAlt(localctx, 4)
                self.state = 204
                self.match(MOCParser.IDENTIFICADOR)
                self.state = 205
                self.match(MOCParser.ABRECOLCH)
                self.state = 206
                self.match(MOCParser.FECHACOLCH)
                self.state = 207
                self.match(MOCParser.ATRIBUICAO)
                self.state = 208
                self.chamadaReads()
                pass

            elif la_ == 5:
                self.enterOuterAlt(localctx, 5)
                self.state = 209
                self.match(MOCParser.IDENTIFICADOR)
                self.state = 210
                self.match(MOCParser.ABRECOLCH)
                self.state = 211
                self.match(MOCParser.FECHACOLCH)
                self.state = 212
                self.match(MOCParser.ATRIBUICAO)
                self.state = 213
                self.blocoArray()
                pass

            elif la_ == 6:
                self.enterOuterAlt(localctx, 6)
                self.state = 214
                self.match(MOCParser.IDENTIFICADOR)
                self.state = 215
                self.match(MOCParser.ABRECOLCH)
                self.state = 216
                self.match(MOCParser.NUMERO)
                self.state = 217
                self.match(MOCParser.FECHACOLCH)
                self.state = 218
                self.match(MOCParser.ATRIBUICAO)
                self.state = 219
                self.blocoArray()
                pass


        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class BlocoArrayContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def ABRECHAVES(self):
            return self.getToken(MOCParser.ABRECHAVES, 0)

        def FECHACHAVES(self):
            return self.getToken(MOCParser.FECHACHAVES, 0)

        def listaValores(self):
            return self.getTypedRuleContext(MOCParser.ListaValoresContext,0)


        def getRuleIndex(self):
            return MOCParser.RULE_blocoArray

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterBlocoArray" ):
                listener.enterBlocoArray(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitBlocoArray" ):
                listener.exitBlocoArray(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitBlocoArray" ):
                return visitor.visitBlocoArray(self)
            else:
                return visitor.visitChildren(self)




    def blocoArray(self):

        localctx = MOCParser.BlocoArrayContext(self, self._ctx, self.state)
        self.enterRule(localctx, 28, self.RULE_blocoArray)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 222
            self.match(MOCParser.ABRECHAVES)
            self.state = 224
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if (((_la) & ~0x3f) == 0 and ((1 << _la) & 61710627111136) != 0):
                self.state = 223
                self.listaValores()


            self.state = 226
            self.match(MOCParser.FECHACHAVES)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class ListaValoresContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def expressao(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(MOCParser.ExpressaoContext)
            else:
                return self.getTypedRuleContext(MOCParser.ExpressaoContext,i)


        def VIRGULA(self, i:int=None):
            if i is None:
                return self.getTokens(MOCParser.VIRGULA)
            else:
                return self.getToken(MOCParser.VIRGULA, i)

        def getRuleIndex(self):
            return MOCParser.RULE_listaValores

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterListaValores" ):
                listener.enterListaValores(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitListaValores" ):
                listener.exitListaValores(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitListaValores" ):
                return visitor.visitListaValores(self)
            else:
                return visitor.visitChildren(self)




    def listaValores(self):

        localctx = MOCParser.ListaValoresContext(self, self._ctx, self.state)
        self.enterRule(localctx, 30, self.RULE_listaValores)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 228
            self.expressao()
            self.state = 233
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while _la==31:
                self.state = 229
                self.match(MOCParser.VIRGULA)
                self.state = 230
                self.expressao()
                self.state = 235
                self._errHandler.sync(self)
                _la = self._input.LA(1)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class ExpressaoContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def expressaoOr(self):
            return self.getTypedRuleContext(MOCParser.ExpressaoOrContext,0)


        def getRuleIndex(self):
            return MOCParser.RULE_expressao

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterExpressao" ):
                listener.enterExpressao(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitExpressao" ):
                listener.exitExpressao(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitExpressao" ):
                return visitor.visitExpressao(self)
            else:
                return visitor.visitChildren(self)




    def expressao(self):

        localctx = MOCParser.ExpressaoContext(self, self._ctx, self.state)
        self.enterRule(localctx, 32, self.RULE_expressao)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 236
            self.expressaoOr(0)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class ExpressaoOrContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser


        def getRuleIndex(self):
            return MOCParser.RULE_expressaoOr

     
        def copyFrom(self, ctx:ParserRuleContext):
            super().copyFrom(ctx)


    class OuSimplesContext(ExpressaoOrContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a MOCParser.ExpressaoOrContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def expressaoAnd(self):
            return self.getTypedRuleContext(MOCParser.ExpressaoAndContext,0)


        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterOuSimples" ):
                listener.enterOuSimples(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitOuSimples" ):
                listener.exitOuSimples(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitOuSimples" ):
                return visitor.visitOuSimples(self)
            else:
                return visitor.visitChildren(self)


    class OuLogicoContext(ExpressaoOrContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a MOCParser.ExpressaoOrContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def expressaoOr(self):
            return self.getTypedRuleContext(MOCParser.ExpressaoOrContext,0)

        def OU_LOGICO(self):
            return self.getToken(MOCParser.OU_LOGICO, 0)
        def expressaoAnd(self):
            return self.getTypedRuleContext(MOCParser.ExpressaoAndContext,0)


        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterOuLogico" ):
                listener.enterOuLogico(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitOuLogico" ):
                listener.exitOuLogico(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitOuLogico" ):
                return visitor.visitOuLogico(self)
            else:
                return visitor.visitChildren(self)



    def expressaoOr(self, _p:int=0):
        _parentctx = self._ctx
        _parentState = self.state
        localctx = MOCParser.ExpressaoOrContext(self, self._ctx, _parentState)
        _prevctx = localctx
        _startState = 34
        self.enterRecursionRule(localctx, 34, self.RULE_expressaoOr, _p)
        try:
            self.enterOuterAlt(localctx, 1)
            localctx = MOCParser.OuSimplesContext(self, localctx)
            self._ctx = localctx
            _prevctx = localctx

            self.state = 239
            self.expressaoAnd(0)
            self._ctx.stop = self._input.LT(-1)
            self.state = 246
            self._errHandler.sync(self)
            _alt = self._interp.adaptivePredict(self._input,17,self._ctx)
            while _alt!=2 and _alt!=ATN.INVALID_ALT_NUMBER:
                if _alt==1:
                    if self._parseListeners is not None:
                        self.triggerExitRuleEvent()
                    _prevctx = localctx
                    localctx = MOCParser.OuLogicoContext(self, MOCParser.ExpressaoOrContext(self, _parentctx, _parentState))
                    self.pushNewRecursionContext(localctx, _startState, self.RULE_expressaoOr)
                    self.state = 241
                    if not self.precpred(self._ctx, 2):
                        from antlr4.error.Errors import FailedPredicateException
                        raise FailedPredicateException(self, "self.precpred(self._ctx, 2)")
                    self.state = 242
                    self.match(MOCParser.OU_LOGICO)
                    self.state = 243
                    self.expressaoAnd(0) 
                self.state = 248
                self._errHandler.sync(self)
                _alt = self._interp.adaptivePredict(self._input,17,self._ctx)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.unrollRecursionContexts(_parentctx)
        return localctx


    class ExpressaoAndContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser


        def getRuleIndex(self):
            return MOCParser.RULE_expressaoAnd

     
        def copyFrom(self, ctx:ParserRuleContext):
            super().copyFrom(ctx)


    class ELogicoContext(ExpressaoAndContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a MOCParser.ExpressaoAndContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def expressaoAnd(self):
            return self.getTypedRuleContext(MOCParser.ExpressaoAndContext,0)

        def E_LOGICO(self):
            return self.getToken(MOCParser.E_LOGICO, 0)
        def expressaoEquality(self):
            return self.getTypedRuleContext(MOCParser.ExpressaoEqualityContext,0)


        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterELogico" ):
                listener.enterELogico(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitELogico" ):
                listener.exitELogico(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitELogico" ):
                return visitor.visitELogico(self)
            else:
                return visitor.visitChildren(self)


    class AndSimplesContext(ExpressaoAndContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a MOCParser.ExpressaoAndContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def expressaoEquality(self):
            return self.getTypedRuleContext(MOCParser.ExpressaoEqualityContext,0)


        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterAndSimples" ):
                listener.enterAndSimples(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitAndSimples" ):
                listener.exitAndSimples(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitAndSimples" ):
                return visitor.visitAndSimples(self)
            else:
                return visitor.visitChildren(self)



    def expressaoAnd(self, _p:int=0):
        _parentctx = self._ctx
        _parentState = self.state
        localctx = MOCParser.ExpressaoAndContext(self, self._ctx, _parentState)
        _prevctx = localctx
        _startState = 36
        self.enterRecursionRule(localctx, 36, self.RULE_expressaoAnd, _p)
        try:
            self.enterOuterAlt(localctx, 1)
            localctx = MOCParser.AndSimplesContext(self, localctx)
            self._ctx = localctx
            _prevctx = localctx

            self.state = 250
            self.expressaoEquality()
            self._ctx.stop = self._input.LT(-1)
            self.state = 257
            self._errHandler.sync(self)
            _alt = self._interp.adaptivePredict(self._input,18,self._ctx)
            while _alt!=2 and _alt!=ATN.INVALID_ALT_NUMBER:
                if _alt==1:
                    if self._parseListeners is not None:
                        self.triggerExitRuleEvent()
                    _prevctx = localctx
                    localctx = MOCParser.ELogicoContext(self, MOCParser.ExpressaoAndContext(self, _parentctx, _parentState))
                    self.pushNewRecursionContext(localctx, _startState, self.RULE_expressaoAnd)
                    self.state = 252
                    if not self.precpred(self._ctx, 2):
                        from antlr4.error.Errors import FailedPredicateException
                        raise FailedPredicateException(self, "self.precpred(self._ctx, 2)")
                    self.state = 253
                    self.match(MOCParser.E_LOGICO)
                    self.state = 254
                    self.expressaoEquality() 
                self.state = 259
                self._errHandler.sync(self)
                _alt = self._interp.adaptivePredict(self._input,18,self._ctx)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.unrollRecursionContexts(_parentctx)
        return localctx


    class ExpressaoEqualityContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser


        def getRuleIndex(self):
            return MOCParser.RULE_expressaoEquality

     
        def copyFrom(self, ctx:ParserRuleContext):
            super().copyFrom(ctx)



    class ComparacaoSimplesContext(ExpressaoEqualityContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a MOCParser.ExpressaoEqualityContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def expressaoAdd(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(MOCParser.ExpressaoAddContext)
            else:
                return self.getTypedRuleContext(MOCParser.ExpressaoAddContext,i)

        def opRelacional(self):
            return self.getTypedRuleContext(MOCParser.OpRelacionalContext,0)


        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterComparacaoSimples" ):
                listener.enterComparacaoSimples(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitComparacaoSimples" ):
                listener.exitComparacaoSimples(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitComparacaoSimples" ):
                return visitor.visitComparacaoSimples(self)
            else:
                return visitor.visitChildren(self)



    def expressaoEquality(self):

        localctx = MOCParser.ExpressaoEqualityContext(self, self._ctx, self.state)
        self.enterRule(localctx, 38, self.RULE_expressaoEquality)
        try:
            localctx = MOCParser.ComparacaoSimplesContext(self, localctx)
            self.enterOuterAlt(localctx, 1)
            self.state = 260
            self.expressaoAdd(0)
            self.state = 264
            self._errHandler.sync(self)
            la_ = self._interp.adaptivePredict(self._input,19,self._ctx)
            if la_ == 1:
                self.state = 261
                self.opRelacional()
                self.state = 262
                self.expressaoAdd(0)


        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class ExpressaoAddContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser


        def getRuleIndex(self):
            return MOCParser.RULE_expressaoAdd

     
        def copyFrom(self, ctx:ParserRuleContext):
            super().copyFrom(ctx)


    class AdicaoContext(ExpressaoAddContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a MOCParser.ExpressaoAddContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def expressaoAdd(self):
            return self.getTypedRuleContext(MOCParser.ExpressaoAddContext,0)

        def MAIS(self):
            return self.getToken(MOCParser.MAIS, 0)
        def expressaoMul(self):
            return self.getTypedRuleContext(MOCParser.ExpressaoMulContext,0)


        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterAdicao" ):
                listener.enterAdicao(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitAdicao" ):
                listener.exitAdicao(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitAdicao" ):
                return visitor.visitAdicao(self)
            else:
                return visitor.visitChildren(self)


    class AddSimplesContext(ExpressaoAddContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a MOCParser.ExpressaoAddContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def expressaoMul(self):
            return self.getTypedRuleContext(MOCParser.ExpressaoMulContext,0)


        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterAddSimples" ):
                listener.enterAddSimples(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitAddSimples" ):
                listener.exitAddSimples(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitAddSimples" ):
                return visitor.visitAddSimples(self)
            else:
                return visitor.visitChildren(self)


    class SubtracaoContext(ExpressaoAddContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a MOCParser.ExpressaoAddContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def expressaoAdd(self):
            return self.getTypedRuleContext(MOCParser.ExpressaoAddContext,0)

        def MENOS(self):
            return self.getToken(MOCParser.MENOS, 0)
        def expressaoMul(self):
            return self.getTypedRuleContext(MOCParser.ExpressaoMulContext,0)


        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterSubtracao" ):
                listener.enterSubtracao(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitSubtracao" ):
                listener.exitSubtracao(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitSubtracao" ):
                return visitor.visitSubtracao(self)
            else:
                return visitor.visitChildren(self)



    def expressaoAdd(self, _p:int=0):
        _parentctx = self._ctx
        _parentState = self.state
        localctx = MOCParser.ExpressaoAddContext(self, self._ctx, _parentState)
        _prevctx = localctx
        _startState = 40
        self.enterRecursionRule(localctx, 40, self.RULE_expressaoAdd, _p)
        try:
            self.enterOuterAlt(localctx, 1)
            localctx = MOCParser.AddSimplesContext(self, localctx)
            self._ctx = localctx
            _prevctx = localctx

            self.state = 267
            self.expressaoMul(0)
            self._ctx.stop = self._input.LT(-1)
            self.state = 277
            self._errHandler.sync(self)
            _alt = self._interp.adaptivePredict(self._input,21,self._ctx)
            while _alt!=2 and _alt!=ATN.INVALID_ALT_NUMBER:
                if _alt==1:
                    if self._parseListeners is not None:
                        self.triggerExitRuleEvent()
                    _prevctx = localctx
                    self.state = 275
                    self._errHandler.sync(self)
                    la_ = self._interp.adaptivePredict(self._input,20,self._ctx)
                    if la_ == 1:
                        localctx = MOCParser.AdicaoContext(self, MOCParser.ExpressaoAddContext(self, _parentctx, _parentState))
                        self.pushNewRecursionContext(localctx, _startState, self.RULE_expressaoAdd)
                        self.state = 269
                        if not self.precpred(self._ctx, 3):
                            from antlr4.error.Errors import FailedPredicateException
                            raise FailedPredicateException(self, "self.precpred(self._ctx, 3)")
                        self.state = 270
                        self.match(MOCParser.MAIS)
                        self.state = 271
                        self.expressaoMul(0)
                        pass

                    elif la_ == 2:
                        localctx = MOCParser.SubtracaoContext(self, MOCParser.ExpressaoAddContext(self, _parentctx, _parentState))
                        self.pushNewRecursionContext(localctx, _startState, self.RULE_expressaoAdd)
                        self.state = 272
                        if not self.precpred(self._ctx, 2):
                            from antlr4.error.Errors import FailedPredicateException
                            raise FailedPredicateException(self, "self.precpred(self._ctx, 2)")
                        self.state = 273
                        self.match(MOCParser.MENOS)
                        self.state = 274
                        self.expressaoMul(0)
                        pass

             
                self.state = 279
                self._errHandler.sync(self)
                _alt = self._interp.adaptivePredict(self._input,21,self._ctx)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.unrollRecursionContexts(_parentctx)
        return localctx


    class ExpressaoMulContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser


        def getRuleIndex(self):
            return MOCParser.RULE_expressaoMul

     
        def copyFrom(self, ctx:ParserRuleContext):
            super().copyFrom(ctx)


    class DivisaoContext(ExpressaoMulContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a MOCParser.ExpressaoMulContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def expressaoMul(self):
            return self.getTypedRuleContext(MOCParser.ExpressaoMulContext,0)

        def DIV(self):
            return self.getToken(MOCParser.DIV, 0)
        def expressaoUnaria(self):
            return self.getTypedRuleContext(MOCParser.ExpressaoUnariaContext,0)


        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterDivisao" ):
                listener.enterDivisao(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitDivisao" ):
                listener.exitDivisao(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitDivisao" ):
                return visitor.visitDivisao(self)
            else:
                return visitor.visitChildren(self)


    class MulSimplesContext(ExpressaoMulContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a MOCParser.ExpressaoMulContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def expressaoUnaria(self):
            return self.getTypedRuleContext(MOCParser.ExpressaoUnariaContext,0)


        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterMulSimples" ):
                listener.enterMulSimples(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitMulSimples" ):
                listener.exitMulSimples(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitMulSimples" ):
                return visitor.visitMulSimples(self)
            else:
                return visitor.visitChildren(self)


    class ModuloContext(ExpressaoMulContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a MOCParser.ExpressaoMulContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def expressaoMul(self):
            return self.getTypedRuleContext(MOCParser.ExpressaoMulContext,0)

        def MODULO(self):
            return self.getToken(MOCParser.MODULO, 0)
        def expressaoUnaria(self):
            return self.getTypedRuleContext(MOCParser.ExpressaoUnariaContext,0)


        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterModulo" ):
                listener.enterModulo(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitModulo" ):
                listener.exitModulo(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitModulo" ):
                return visitor.visitModulo(self)
            else:
                return visitor.visitChildren(self)


    class MultiplicacaoContext(ExpressaoMulContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a MOCParser.ExpressaoMulContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def expressaoMul(self):
            return self.getTypedRuleContext(MOCParser.ExpressaoMulContext,0)

        def MULT(self):
            return self.getToken(MOCParser.MULT, 0)
        def expressaoUnaria(self):
            return self.getTypedRuleContext(MOCParser.ExpressaoUnariaContext,0)


        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterMultiplicacao" ):
                listener.enterMultiplicacao(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitMultiplicacao" ):
                listener.exitMultiplicacao(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitMultiplicacao" ):
                return visitor.visitMultiplicacao(self)
            else:
                return visitor.visitChildren(self)



    def expressaoMul(self, _p:int=0):
        _parentctx = self._ctx
        _parentState = self.state
        localctx = MOCParser.ExpressaoMulContext(self, self._ctx, _parentState)
        _prevctx = localctx
        _startState = 42
        self.enterRecursionRule(localctx, 42, self.RULE_expressaoMul, _p)
        try:
            self.enterOuterAlt(localctx, 1)
            localctx = MOCParser.MulSimplesContext(self, localctx)
            self._ctx = localctx
            _prevctx = localctx

            self.state = 281
            self.expressaoUnaria()
            self._ctx.stop = self._input.LT(-1)
            self.state = 294
            self._errHandler.sync(self)
            _alt = self._interp.adaptivePredict(self._input,23,self._ctx)
            while _alt!=2 and _alt!=ATN.INVALID_ALT_NUMBER:
                if _alt==1:
                    if self._parseListeners is not None:
                        self.triggerExitRuleEvent()
                    _prevctx = localctx
                    self.state = 292
                    self._errHandler.sync(self)
                    la_ = self._interp.adaptivePredict(self._input,22,self._ctx)
                    if la_ == 1:
                        localctx = MOCParser.MultiplicacaoContext(self, MOCParser.ExpressaoMulContext(self, _parentctx, _parentState))
                        self.pushNewRecursionContext(localctx, _startState, self.RULE_expressaoMul)
                        self.state = 283
                        if not self.precpred(self._ctx, 4):
                            from antlr4.error.Errors import FailedPredicateException
                            raise FailedPredicateException(self, "self.precpred(self._ctx, 4)")
                        self.state = 284
                        self.match(MOCParser.MULT)
                        self.state = 285
                        self.expressaoUnaria()
                        pass

                    elif la_ == 2:
                        localctx = MOCParser.DivisaoContext(self, MOCParser.ExpressaoMulContext(self, _parentctx, _parentState))
                        self.pushNewRecursionContext(localctx, _startState, self.RULE_expressaoMul)
                        self.state = 286
                        if not self.precpred(self._ctx, 3):
                            from antlr4.error.Errors import FailedPredicateException
                            raise FailedPredicateException(self, "self.precpred(self._ctx, 3)")
                        self.state = 287
                        self.match(MOCParser.DIV)
                        self.state = 288
                        self.expressaoUnaria()
                        pass

                    elif la_ == 3:
                        localctx = MOCParser.ModuloContext(self, MOCParser.ExpressaoMulContext(self, _parentctx, _parentState))
                        self.pushNewRecursionContext(localctx, _startState, self.RULE_expressaoMul)
                        self.state = 289
                        if not self.precpred(self._ctx, 2):
                            from antlr4.error.Errors import FailedPredicateException
                            raise FailedPredicateException(self, "self.precpred(self._ctx, 2)")
                        self.state = 290
                        self.match(MOCParser.MODULO)
                        self.state = 291
                        self.expressaoUnaria()
                        pass

             
                self.state = 296
                self._errHandler.sync(self)
                _alt = self._interp.adaptivePredict(self._input,23,self._ctx)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.unrollRecursionContexts(_parentctx)
        return localctx


    class ExpressaoUnariaContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser


        def getRuleIndex(self):
            return MOCParser.RULE_expressaoUnaria

     
        def copyFrom(self, ctx:ParserRuleContext):
            super().copyFrom(ctx)



    class UnarioNegativoContext(ExpressaoUnariaContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a MOCParser.ExpressaoUnariaContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def MENOS(self):
            return self.getToken(MOCParser.MENOS, 0)
        def expressaoUnaria(self):
            return self.getTypedRuleContext(MOCParser.ExpressaoUnariaContext,0)


        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterUnarioNegativo" ):
                listener.enterUnarioNegativo(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitUnarioNegativo" ):
                listener.exitUnarioNegativo(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitUnarioNegativo" ):
                return visitor.visitUnarioNegativo(self)
            else:
                return visitor.visitChildren(self)


    class UnariaSimplesContext(ExpressaoUnariaContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a MOCParser.ExpressaoUnariaContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def castExpr(self):
            return self.getTypedRuleContext(MOCParser.CastExprContext,0)


        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterUnariaSimples" ):
                listener.enterUnariaSimples(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitUnariaSimples" ):
                listener.exitUnariaSimples(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitUnariaSimples" ):
                return visitor.visitUnariaSimples(self)
            else:
                return visitor.visitChildren(self)


    class NegacaoContext(ExpressaoUnariaContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a MOCParser.ExpressaoUnariaContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def NAO(self):
            return self.getToken(MOCParser.NAO, 0)
        def expressaoUnaria(self):
            return self.getTypedRuleContext(MOCParser.ExpressaoUnariaContext,0)


        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterNegacao" ):
                listener.enterNegacao(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitNegacao" ):
                listener.exitNegacao(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitNegacao" ):
                return visitor.visitNegacao(self)
            else:
                return visitor.visitChildren(self)



    def expressaoUnaria(self):

        localctx = MOCParser.ExpressaoUnariaContext(self, self._ctx, self.state)
        self.enterRule(localctx, 44, self.RULE_expressaoUnaria)
        try:
            self.state = 302
            self._errHandler.sync(self)
            token = self._input.LA(1)
            if token in [29]:
                localctx = MOCParser.NegacaoContext(self, localctx)
                self.enterOuterAlt(localctx, 1)
                self.state = 297
                self.match(MOCParser.NAO)
                self.state = 298
                self.expressaoUnaria()
                pass
            elif token in [17]:
                localctx = MOCParser.UnarioNegativoContext(self, localctx)
                self.enterOuterAlt(localctx, 2)
                self.state = 299
                self.match(MOCParser.MENOS)
                self.state = 300
                self.expressaoUnaria()
                pass
            elif token in [5, 6, 7, 37, 43, 44, 45]:
                localctx = MOCParser.UnariaSimplesContext(self, localctx)
                self.enterOuterAlt(localctx, 3)
                self.state = 301
                self.castExpr()
                pass
            else:
                raise NoViableAltException(self)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class CastExprContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser


        def getRuleIndex(self):
            return MOCParser.RULE_castExpr

     
        def copyFrom(self, ctx:ParserRuleContext):
            super().copyFrom(ctx)



    class CastSimplesContext(CastExprContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a MOCParser.CastExprContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def primary(self):
            return self.getTypedRuleContext(MOCParser.PrimaryContext,0)


        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterCastSimples" ):
                listener.enterCastSimples(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitCastSimples" ):
                listener.exitCastSimples(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitCastSimples" ):
                return visitor.visitCastSimples(self)
            else:
                return visitor.visitChildren(self)


    class CastingContext(CastExprContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a MOCParser.CastExprContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def ABREPAR(self):
            return self.getToken(MOCParser.ABREPAR, 0)
        def tipo(self):
            return self.getTypedRuleContext(MOCParser.TipoContext,0)

        def FECHAPAR(self):
            return self.getToken(MOCParser.FECHAPAR, 0)
        def castExpr(self):
            return self.getTypedRuleContext(MOCParser.CastExprContext,0)


        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterCasting" ):
                listener.enterCasting(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitCasting" ):
                listener.exitCasting(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitCasting" ):
                return visitor.visitCasting(self)
            else:
                return visitor.visitChildren(self)



    def castExpr(self):

        localctx = MOCParser.CastExprContext(self, self._ctx, self.state)
        self.enterRule(localctx, 46, self.RULE_castExpr)
        try:
            self.state = 310
            self._errHandler.sync(self)
            la_ = self._interp.adaptivePredict(self._input,25,self._ctx)
            if la_ == 1:
                localctx = MOCParser.CastingContext(self, localctx)
                self.enterOuterAlt(localctx, 1)
                self.state = 304
                self.match(MOCParser.ABREPAR)
                self.state = 305
                self.tipo()
                self.state = 306
                self.match(MOCParser.FECHAPAR)
                self.state = 307
                self.castExpr()
                pass

            elif la_ == 2:
                localctx = MOCParser.CastSimplesContext(self, localctx)
                self.enterOuterAlt(localctx, 2)
                self.state = 309
                self.primary()
                pass


        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class PrimaryContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser


        def getRuleIndex(self):
            return MOCParser.RULE_primary

     
        def copyFrom(self, ctx:ParserRuleContext):
            super().copyFrom(ctx)



    class ChamadaLeituraContext(PrimaryContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a MOCParser.PrimaryContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def chamadaFuncao(self):
            return self.getTypedRuleContext(MOCParser.ChamadaFuncaoContext,0)


        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterChamadaLeitura" ):
                listener.enterChamadaLeitura(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitChamadaLeitura" ):
                listener.exitChamadaLeitura(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitChamadaLeitura" ):
                return visitor.visitChamadaLeitura(self)
            else:
                return visitor.visitChildren(self)


    class ParentesesContext(PrimaryContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a MOCParser.PrimaryContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def ABREPAR(self):
            return self.getToken(MOCParser.ABREPAR, 0)
        def expressao(self):
            return self.getTypedRuleContext(MOCParser.ExpressaoContext,0)

        def FECHAPAR(self):
            return self.getToken(MOCParser.FECHAPAR, 0)

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterParenteses" ):
                listener.enterParenteses(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitParenteses" ):
                listener.exitParenteses(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitParenteses" ):
                return visitor.visitParenteses(self)
            else:
                return visitor.visitChildren(self)


    class NumeroContext(PrimaryContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a MOCParser.PrimaryContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def NUMERO(self):
            return self.getToken(MOCParser.NUMERO, 0)

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterNumero" ):
                listener.enterNumero(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitNumero" ):
                listener.exitNumero(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitNumero" ):
                return visitor.visitNumero(self)
            else:
                return visitor.visitChildren(self)


    class IdComPrefixoContext(PrimaryContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a MOCParser.PrimaryContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def IDENTIFICADOR(self):
            return self.getToken(MOCParser.IDENTIFICADOR, 0)
        def primaryRest(self):
            return self.getTypedRuleContext(MOCParser.PrimaryRestContext,0)


        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterIdComPrefixo" ):
                listener.enterIdComPrefixo(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitIdComPrefixo" ):
                listener.exitIdComPrefixo(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitIdComPrefixo" ):
                return visitor.visitIdComPrefixo(self)
            else:
                return visitor.visitChildren(self)


    class NumeroRealContext(PrimaryContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a MOCParser.PrimaryContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def NUM_REAL(self):
            return self.getToken(MOCParser.NUM_REAL, 0)

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterNumeroReal" ):
                listener.enterNumeroReal(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitNumeroReal" ):
                listener.exitNumeroReal(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitNumeroReal" ):
                return visitor.visitNumeroReal(self)
            else:
                return visitor.visitChildren(self)



    def primary(self):

        localctx = MOCParser.PrimaryContext(self, self._ctx, self.state)
        self.enterRule(localctx, 48, self.RULE_primary)
        try:
            self.state = 321
            self._errHandler.sync(self)
            token = self._input.LA(1)
            if token in [37]:
                localctx = MOCParser.ParentesesContext(self, localctx)
                self.enterOuterAlt(localctx, 1)
                self.state = 312
                self.match(MOCParser.ABREPAR)
                self.state = 313
                self.expressao()
                self.state = 314
                self.match(MOCParser.FECHAPAR)
                pass
            elif token in [5, 6, 7]:
                localctx = MOCParser.ChamadaLeituraContext(self, localctx)
                self.enterOuterAlt(localctx, 2)
                self.state = 316
                self.chamadaFuncao()
                pass
            elif token in [44]:
                localctx = MOCParser.NumeroContext(self, localctx)
                self.enterOuterAlt(localctx, 3)
                self.state = 317
                self.match(MOCParser.NUMERO)
                pass
            elif token in [43]:
                localctx = MOCParser.NumeroRealContext(self, localctx)
                self.enterOuterAlt(localctx, 4)
                self.state = 318
                self.match(MOCParser.NUM_REAL)
                pass
            elif token in [45]:
                localctx = MOCParser.IdComPrefixoContext(self, localctx)
                self.enterOuterAlt(localctx, 5)
                self.state = 319
                self.match(MOCParser.IDENTIFICADOR)
                self.state = 320
                self.primaryRest()
                pass
            else:
                raise NoViableAltException(self)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class PrimaryRestContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser


        def getRuleIndex(self):
            return MOCParser.RULE_primaryRest

     
        def copyFrom(self, ctx:ParserRuleContext):
            super().copyFrom(ctx)



    class ChamadaGenericaContext(PrimaryRestContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a MOCParser.PrimaryRestContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def ABREPAR(self):
            return self.getToken(MOCParser.ABREPAR, 0)
        def FECHAPAR(self):
            return self.getToken(MOCParser.FECHAPAR, 0)
        def argumentos(self):
            return self.getTypedRuleContext(MOCParser.ArgumentosContext,0)


        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterChamadaGenerica" ):
                listener.enterChamadaGenerica(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitChamadaGenerica" ):
                listener.exitChamadaGenerica(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitChamadaGenerica" ):
                return visitor.visitChamadaGenerica(self)
            else:
                return visitor.visitChildren(self)


    class SemSufixoContext(PrimaryRestContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a MOCParser.PrimaryRestContext
            super().__init__(parser)
            self.copyFrom(ctx)


        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterSemSufixo" ):
                listener.enterSemSufixo(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitSemSufixo" ):
                listener.exitSemSufixo(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitSemSufixo" ):
                return visitor.visitSemSufixo(self)
            else:
                return visitor.visitChildren(self)


    class AcessoVetorContext(PrimaryRestContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a MOCParser.PrimaryRestContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def ABRECOLCH(self):
            return self.getToken(MOCParser.ABRECOLCH, 0)
        def expressao(self):
            return self.getTypedRuleContext(MOCParser.ExpressaoContext,0)

        def FECHACOLCH(self):
            return self.getToken(MOCParser.FECHACOLCH, 0)

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterAcessoVetor" ):
                listener.enterAcessoVetor(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitAcessoVetor" ):
                listener.exitAcessoVetor(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitAcessoVetor" ):
                return visitor.visitAcessoVetor(self)
            else:
                return visitor.visitChildren(self)



    def primaryRest(self):

        localctx = MOCParser.PrimaryRestContext(self, self._ctx, self.state)
        self.enterRule(localctx, 50, self.RULE_primaryRest)
        self._la = 0 # Token type
        try:
            self.state = 333
            self._errHandler.sync(self)
            la_ = self._interp.adaptivePredict(self._input,28,self._ctx)
            if la_ == 1:
                localctx = MOCParser.ChamadaGenericaContext(self, localctx)
                self.enterOuterAlt(localctx, 1)
                self.state = 323
                self.match(MOCParser.ABREPAR)
                self.state = 325
                self._errHandler.sync(self)
                _la = self._input.LA(1)
                if (((_la) & ~0x3f) == 0 and ((1 << _la) & 61710627111136) != 0):
                    self.state = 324
                    self.argumentos()


                self.state = 327
                self.match(MOCParser.FECHAPAR)
                pass

            elif la_ == 2:
                localctx = MOCParser.AcessoVetorContext(self, localctx)
                self.enterOuterAlt(localctx, 2)
                self.state = 328
                self.match(MOCParser.ABRECOLCH)
                self.state = 329
                self.expressao()
                self.state = 330
                self.match(MOCParser.FECHACOLCH)
                pass

            elif la_ == 3:
                localctx = MOCParser.SemSufixoContext(self, localctx)
                self.enterOuterAlt(localctx, 3)

                pass


        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class ArgumentosContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def expressao(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(MOCParser.ExpressaoContext)
            else:
                return self.getTypedRuleContext(MOCParser.ExpressaoContext,i)


        def VIRGULA(self, i:int=None):
            if i is None:
                return self.getTokens(MOCParser.VIRGULA)
            else:
                return self.getToken(MOCParser.VIRGULA, i)

        def getRuleIndex(self):
            return MOCParser.RULE_argumentos

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterArgumentos" ):
                listener.enterArgumentos(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitArgumentos" ):
                listener.exitArgumentos(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitArgumentos" ):
                return visitor.visitArgumentos(self)
            else:
                return visitor.visitChildren(self)




    def argumentos(self):

        localctx = MOCParser.ArgumentosContext(self, self._ctx, self.state)
        self.enterRule(localctx, 52, self.RULE_argumentos)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 335
            self.expressao()
            self.state = 340
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while _la==31:
                self.state = 336
                self.match(MOCParser.VIRGULA)
                self.state = 337
                self.expressao()
                self.state = 342
                self._errHandler.sync(self)
                _la = self._input.LA(1)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class OpRelacionalContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def MENOR(self):
            return self.getToken(MOCParser.MENOR, 0)

        def MENORIGUAL(self):
            return self.getToken(MOCParser.MENORIGUAL, 0)

        def MAIOR(self):
            return self.getToken(MOCParser.MAIOR, 0)

        def MAIORIGUAL(self):
            return self.getToken(MOCParser.MAIORIGUAL, 0)

        def IGUAL(self):
            return self.getToken(MOCParser.IGUAL, 0)

        def DIFERENTE(self):
            return self.getToken(MOCParser.DIFERENTE, 0)

        def getRuleIndex(self):
            return MOCParser.RULE_opRelacional

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterOpRelacional" ):
                listener.enterOpRelacional(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitOpRelacional" ):
                listener.exitOpRelacional(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitOpRelacional" ):
                return visitor.visitOpRelacional(self)
            else:
                return visitor.visitChildren(self)




    def opRelacional(self):

        localctx = MOCParser.OpRelacionalContext(self, self._ctx, self.state)
        self.enterRule(localctx, 54, self.RULE_opRelacional)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 343
            _la = self._input.LA(1)
            if not((((_la) & ~0x3f) == 0 and ((1 << _la) & 132120576) != 0)):
                self._errHandler.recoverInline(self)
            else:
                self._errHandler.reportMatch(self)
                self.consume()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class ChamadaFuncaoContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def READ(self):
            return self.getToken(MOCParser.READ, 0)

        def ABREPAR(self):
            return self.getToken(MOCParser.ABREPAR, 0)

        def FECHAPAR(self):
            return self.getToken(MOCParser.FECHAPAR, 0)

        def READC(self):
            return self.getToken(MOCParser.READC, 0)

        def READS(self):
            return self.getToken(MOCParser.READS, 0)

        def getRuleIndex(self):
            return MOCParser.RULE_chamadaFuncao

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterChamadaFuncao" ):
                listener.enterChamadaFuncao(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitChamadaFuncao" ):
                listener.exitChamadaFuncao(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitChamadaFuncao" ):
                return visitor.visitChamadaFuncao(self)
            else:
                return visitor.visitChildren(self)




    def chamadaFuncao(self):

        localctx = MOCParser.ChamadaFuncaoContext(self, self._ctx, self.state)
        self.enterRule(localctx, 56, self.RULE_chamadaFuncao)
        try:
            self.state = 354
            self._errHandler.sync(self)
            token = self._input.LA(1)
            if token in [5]:
                self.enterOuterAlt(localctx, 1)
                self.state = 345
                self.match(MOCParser.READ)
                self.state = 346
                self.match(MOCParser.ABREPAR)
                self.state = 347
                self.match(MOCParser.FECHAPAR)
                pass
            elif token in [6]:
                self.enterOuterAlt(localctx, 2)
                self.state = 348
                self.match(MOCParser.READC)
                self.state = 349
                self.match(MOCParser.ABREPAR)
                self.state = 350
                self.match(MOCParser.FECHAPAR)
                pass
            elif token in [7]:
                self.enterOuterAlt(localctx, 3)
                self.state = 351
                self.match(MOCParser.READS)
                self.state = 352
                self.match(MOCParser.ABREPAR)
                self.state = 353
                self.match(MOCParser.FECHAPAR)
                pass
            else:
                raise NoViableAltException(self)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class ChamadaReadsContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def READS(self):
            return self.getToken(MOCParser.READS, 0)

        def ABREPAR(self):
            return self.getToken(MOCParser.ABREPAR, 0)

        def FECHAPAR(self):
            return self.getToken(MOCParser.FECHAPAR, 0)

        def getRuleIndex(self):
            return MOCParser.RULE_chamadaReads

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterChamadaReads" ):
                listener.enterChamadaReads(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitChamadaReads" ):
                listener.exitChamadaReads(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitChamadaReads" ):
                return visitor.visitChamadaReads(self)
            else:
                return visitor.visitChildren(self)




    def chamadaReads(self):

        localctx = MOCParser.ChamadaReadsContext(self, self._ctx, self.state)
        self.enterRule(localctx, 58, self.RULE_chamadaReads)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 356
            self.match(MOCParser.READS)
            self.state = 357
            self.match(MOCParser.ABREPAR)
            self.state = 358
            self.match(MOCParser.FECHAPAR)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class BlocoContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def ABRECHAVES(self):
            return self.getToken(MOCParser.ABRECHAVES, 0)

        def instrucoes(self):
            return self.getTypedRuleContext(MOCParser.InstrucoesContext,0)


        def FECHACHAVES(self):
            return self.getToken(MOCParser.FECHACHAVES, 0)

        def getRuleIndex(self):
            return MOCParser.RULE_bloco

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterBloco" ):
                listener.enterBloco(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitBloco" ):
                listener.exitBloco(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitBloco" ):
                return visitor.visitBloco(self)
            else:
                return visitor.visitChildren(self)




    def bloco(self):

        localctx = MOCParser.BlocoContext(self, self._ctx, self.state)
        self.enterRule(localctx, 60, self.RULE_bloco)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 360
            self.match(MOCParser.ABRECHAVES)
            self.state = 361
            self.instrucoes()
            self.state = 362
            self.match(MOCParser.FECHACHAVES)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class InstrucoesContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def instrucao(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(MOCParser.InstrucaoContext)
            else:
                return self.getTypedRuleContext(MOCParser.InstrucaoContext,i)


        def getRuleIndex(self):
            return MOCParser.RULE_instrucoes

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterInstrucoes" ):
                listener.enterInstrucoes(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitInstrucoes" ):
                listener.exitInstrucoes(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitInstrucoes" ):
                return visitor.visitInstrucoes(self)
            else:
                return visitor.visitChildren(self)




    def instrucoes(self):

        localctx = MOCParser.InstrucoesContext(self, self._ctx, self.state)
        self.enterRule(localctx, 62, self.RULE_instrucoes)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 367
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while (((_la) & ~0x3f) == 0 and ((1 << _la) & 62294742720494) != 0):
                self.state = 364
                self.instrucao()
                self.state = 369
                self._errHandler.sync(self)
                _la = self._input.LA(1)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class InstrucaoContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def instrucaoEmparelhada(self):
            return self.getTypedRuleContext(MOCParser.InstrucaoEmparelhadaContext,0)


        def instrucaoPorEmparelhar(self):
            return self.getTypedRuleContext(MOCParser.InstrucaoPorEmparelharContext,0)


        def outraInstrucao(self):
            return self.getTypedRuleContext(MOCParser.OutraInstrucaoContext,0)


        def getRuleIndex(self):
            return MOCParser.RULE_instrucao

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterInstrucao" ):
                listener.enterInstrucao(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitInstrucao" ):
                listener.exitInstrucao(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitInstrucao" ):
                return visitor.visitInstrucao(self)
            else:
                return visitor.visitChildren(self)




    def instrucao(self):

        localctx = MOCParser.InstrucaoContext(self, self._ctx, self.state)
        self.enterRule(localctx, 64, self.RULE_instrucao)
        try:
            self.state = 373
            self._errHandler.sync(self)
            la_ = self._interp.adaptivePredict(self._input,32,self._ctx)
            if la_ == 1:
                self.enterOuterAlt(localctx, 1)
                self.state = 370
                self.instrucaoEmparelhada()
                pass

            elif la_ == 2:
                self.enterOuterAlt(localctx, 2)
                self.state = 371
                self.instrucaoPorEmparelhar()
                pass

            elif la_ == 3:
                self.enterOuterAlt(localctx, 3)
                self.state = 372
                self.outraInstrucao()
                pass


        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class InstrucaoExpressaoContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def expressao(self):
            return self.getTypedRuleContext(MOCParser.ExpressaoContext,0)


        def PONTOVIRG(self):
            return self.getToken(MOCParser.PONTOVIRG, 0)

        def getRuleIndex(self):
            return MOCParser.RULE_instrucaoExpressao

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterInstrucaoExpressao" ):
                listener.enterInstrucaoExpressao(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitInstrucaoExpressao" ):
                listener.exitInstrucaoExpressao(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitInstrucaoExpressao" ):
                return visitor.visitInstrucaoExpressao(self)
            else:
                return visitor.visitChildren(self)




    def instrucaoExpressao(self):

        localctx = MOCParser.InstrucaoExpressaoContext(self, self._ctx, self.state)
        self.enterRule(localctx, 66, self.RULE_instrucaoExpressao)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 375
            self.expressao()
            self.state = 376
            self.match(MOCParser.PONTOVIRG)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class InstrucaoEmparelhadaContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def IF(self):
            return self.getToken(MOCParser.IF, 0)

        def ABREPAR(self):
            return self.getToken(MOCParser.ABREPAR, 0)

        def expressao(self):
            return self.getTypedRuleContext(MOCParser.ExpressaoContext,0)


        def FECHAPAR(self):
            return self.getToken(MOCParser.FECHAPAR, 0)

        def bloco(self):
            return self.getTypedRuleContext(MOCParser.BlocoContext,0)


        def ELSE(self):
            return self.getToken(MOCParser.ELSE, 0)

        def instrucaoEmparelhada(self):
            return self.getTypedRuleContext(MOCParser.InstrucaoEmparelhadaContext,0)


        def getRuleIndex(self):
            return MOCParser.RULE_instrucaoEmparelhada

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterInstrucaoEmparelhada" ):
                listener.enterInstrucaoEmparelhada(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitInstrucaoEmparelhada" ):
                listener.exitInstrucaoEmparelhada(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitInstrucaoEmparelhada" ):
                return visitor.visitInstrucaoEmparelhada(self)
            else:
                return visitor.visitChildren(self)




    def instrucaoEmparelhada(self):

        localctx = MOCParser.InstrucaoEmparelhadaContext(self, self._ctx, self.state)
        self.enterRule(localctx, 68, self.RULE_instrucaoEmparelhada)
        try:
            self.state = 387
            self._errHandler.sync(self)
            token = self._input.LA(1)
            if token in [12]:
                self.enterOuterAlt(localctx, 1)
                self.state = 378
                self.match(MOCParser.IF)
                self.state = 379
                self.match(MOCParser.ABREPAR)
                self.state = 380
                self.expressao()
                self.state = 381
                self.match(MOCParser.FECHAPAR)
                self.state = 382
                self.bloco()
                self.state = 383
                self.match(MOCParser.ELSE)
                self.state = 384
                self.instrucaoEmparelhada()
                pass
            elif token in [35]:
                self.enterOuterAlt(localctx, 2)
                self.state = 386
                self.bloco()
                pass
            else:
                raise NoViableAltException(self)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class InstrucaoPorEmparelharContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def IF(self):
            return self.getToken(MOCParser.IF, 0)

        def ABREPAR(self):
            return self.getToken(MOCParser.ABREPAR, 0)

        def expressao(self):
            return self.getTypedRuleContext(MOCParser.ExpressaoContext,0)


        def FECHAPAR(self):
            return self.getToken(MOCParser.FECHAPAR, 0)

        def bloco(self):
            return self.getTypedRuleContext(MOCParser.BlocoContext,0)


        def ELSE(self):
            return self.getToken(MOCParser.ELSE, 0)

        def instrucaoPorEmparelhar(self):
            return self.getTypedRuleContext(MOCParser.InstrucaoPorEmparelharContext,0)


        def getRuleIndex(self):
            return MOCParser.RULE_instrucaoPorEmparelhar

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterInstrucaoPorEmparelhar" ):
                listener.enterInstrucaoPorEmparelhar(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitInstrucaoPorEmparelhar" ):
                listener.exitInstrucaoPorEmparelhar(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitInstrucaoPorEmparelhar" ):
                return visitor.visitInstrucaoPorEmparelhar(self)
            else:
                return visitor.visitChildren(self)




    def instrucaoPorEmparelhar(self):

        localctx = MOCParser.InstrucaoPorEmparelharContext(self, self._ctx, self.state)
        self.enterRule(localctx, 70, self.RULE_instrucaoPorEmparelhar)
        try:
            self.state = 403
            self._errHandler.sync(self)
            la_ = self._interp.adaptivePredict(self._input,34,self._ctx)
            if la_ == 1:
                self.enterOuterAlt(localctx, 1)
                self.state = 389
                self.match(MOCParser.IF)
                self.state = 390
                self.match(MOCParser.ABREPAR)
                self.state = 391
                self.expressao()
                self.state = 392
                self.match(MOCParser.FECHAPAR)
                self.state = 393
                self.bloco()
                pass

            elif la_ == 2:
                self.enterOuterAlt(localctx, 2)
                self.state = 395
                self.match(MOCParser.IF)
                self.state = 396
                self.match(MOCParser.ABREPAR)
                self.state = 397
                self.expressao()
                self.state = 398
                self.match(MOCParser.FECHAPAR)
                self.state = 399
                self.bloco()
                self.state = 400
                self.match(MOCParser.ELSE)
                self.state = 401
                self.instrucaoPorEmparelhar()
                pass


        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class OutraInstrucaoContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def bloco(self):
            return self.getTypedRuleContext(MOCParser.BlocoContext,0)


        def declaracao(self):
            return self.getTypedRuleContext(MOCParser.DeclaracaoContext,0)


        def instrucaoWhile(self):
            return self.getTypedRuleContext(MOCParser.InstrucaoWhileContext,0)


        def instrucaoFor(self):
            return self.getTypedRuleContext(MOCParser.InstrucaoForContext,0)


        def instrucaoEscrita(self):
            return self.getTypedRuleContext(MOCParser.InstrucaoEscritaContext,0)


        def instrucaoReturn(self):
            return self.getTypedRuleContext(MOCParser.InstrucaoReturnContext,0)


        def instrucaoAtribuicao(self):
            return self.getTypedRuleContext(MOCParser.InstrucaoAtribuicaoContext,0)


        def instrucaoExpressao(self):
            return self.getTypedRuleContext(MOCParser.InstrucaoExpressaoContext,0)


        def getRuleIndex(self):
            return MOCParser.RULE_outraInstrucao

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterOutraInstrucao" ):
                listener.enterOutraInstrucao(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitOutraInstrucao" ):
                listener.exitOutraInstrucao(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitOutraInstrucao" ):
                return visitor.visitOutraInstrucao(self)
            else:
                return visitor.visitChildren(self)




    def outraInstrucao(self):

        localctx = MOCParser.OutraInstrucaoContext(self, self._ctx, self.state)
        self.enterRule(localctx, 72, self.RULE_outraInstrucao)
        try:
            self.state = 413
            self._errHandler.sync(self)
            la_ = self._interp.adaptivePredict(self._input,35,self._ctx)
            if la_ == 1:
                self.enterOuterAlt(localctx, 1)
                self.state = 405
                self.bloco()
                pass

            elif la_ == 2:
                self.enterOuterAlt(localctx, 2)
                self.state = 406
                self.declaracao()
                pass

            elif la_ == 3:
                self.enterOuterAlt(localctx, 3)
                self.state = 407
                self.instrucaoWhile()
                pass

            elif la_ == 4:
                self.enterOuterAlt(localctx, 4)
                self.state = 408
                self.instrucaoFor()
                pass

            elif la_ == 5:
                self.enterOuterAlt(localctx, 5)
                self.state = 409
                self.instrucaoEscrita()
                pass

            elif la_ == 6:
                self.enterOuterAlt(localctx, 6)
                self.state = 410
                self.instrucaoReturn()
                pass

            elif la_ == 7:
                self.enterOuterAlt(localctx, 7)
                self.state = 411
                self.instrucaoAtribuicao()
                pass

            elif la_ == 8:
                self.enterOuterAlt(localctx, 8)
                self.state = 412
                self.instrucaoExpressao()
                pass


        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class InstrucaoWhileContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def WHILE(self):
            return self.getToken(MOCParser.WHILE, 0)

        def ABREPAR(self):
            return self.getToken(MOCParser.ABREPAR, 0)

        def expressao(self):
            return self.getTypedRuleContext(MOCParser.ExpressaoContext,0)


        def FECHAPAR(self):
            return self.getToken(MOCParser.FECHAPAR, 0)

        def bloco(self):
            return self.getTypedRuleContext(MOCParser.BlocoContext,0)


        def getRuleIndex(self):
            return MOCParser.RULE_instrucaoWhile

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterInstrucaoWhile" ):
                listener.enterInstrucaoWhile(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitInstrucaoWhile" ):
                listener.exitInstrucaoWhile(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitInstrucaoWhile" ):
                return visitor.visitInstrucaoWhile(self)
            else:
                return visitor.visitChildren(self)




    def instrucaoWhile(self):

        localctx = MOCParser.InstrucaoWhileContext(self, self._ctx, self.state)
        self.enterRule(localctx, 74, self.RULE_instrucaoWhile)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 415
            self.match(MOCParser.WHILE)
            self.state = 416
            self.match(MOCParser.ABREPAR)
            self.state = 417
            self.expressao()
            self.state = 418
            self.match(MOCParser.FECHAPAR)
            self.state = 419
            self.bloco()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class InstrucaoForContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def FOR(self):
            return self.getToken(MOCParser.FOR, 0)

        def ABREPAR(self):
            return self.getToken(MOCParser.ABREPAR, 0)

        def PONTOVIRG(self, i:int=None):
            if i is None:
                return self.getTokens(MOCParser.PONTOVIRG)
            else:
                return self.getToken(MOCParser.PONTOVIRG, i)

        def FECHAPAR(self):
            return self.getToken(MOCParser.FECHAPAR, 0)

        def bloco(self):
            return self.getTypedRuleContext(MOCParser.BlocoContext,0)


        def expressaoOuAtribuicao(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(MOCParser.ExpressaoOuAtribuicaoContext)
            else:
                return self.getTypedRuleContext(MOCParser.ExpressaoOuAtribuicaoContext,i)


        def expressao(self):
            return self.getTypedRuleContext(MOCParser.ExpressaoContext,0)


        def getRuleIndex(self):
            return MOCParser.RULE_instrucaoFor

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterInstrucaoFor" ):
                listener.enterInstrucaoFor(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitInstrucaoFor" ):
                listener.exitInstrucaoFor(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitInstrucaoFor" ):
                return visitor.visitInstrucaoFor(self)
            else:
                return visitor.visitChildren(self)




    def instrucaoFor(self):

        localctx = MOCParser.InstrucaoForContext(self, self._ctx, self.state)
        self.enterRule(localctx, 76, self.RULE_instrucaoFor)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 421
            self.match(MOCParser.FOR)
            self.state = 422
            self.match(MOCParser.ABREPAR)
            self.state = 424
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if (((_la) & ~0x3f) == 0 and ((1 << _la) & 61710627111136) != 0):
                self.state = 423
                self.expressaoOuAtribuicao()


            self.state = 426
            self.match(MOCParser.PONTOVIRG)
            self.state = 428
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if (((_la) & ~0x3f) == 0 and ((1 << _la) & 61710627111136) != 0):
                self.state = 427
                self.expressao()


            self.state = 430
            self.match(MOCParser.PONTOVIRG)
            self.state = 432
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if (((_la) & ~0x3f) == 0 and ((1 << _la) & 61710627111136) != 0):
                self.state = 431
                self.expressaoOuAtribuicao()


            self.state = 434
            self.match(MOCParser.FECHAPAR)
            self.state = 435
            self.bloco()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class ExpressaoOuAtribuicaoContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def IDENTIFICADOR(self):
            return self.getToken(MOCParser.IDENTIFICADOR, 0)

        def ATRIBUICAO(self):
            return self.getToken(MOCParser.ATRIBUICAO, 0)

        def expressao(self):
            return self.getTypedRuleContext(MOCParser.ExpressaoContext,0)


        def getRuleIndex(self):
            return MOCParser.RULE_expressaoOuAtribuicao

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterExpressaoOuAtribuicao" ):
                listener.enterExpressaoOuAtribuicao(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitExpressaoOuAtribuicao" ):
                listener.exitExpressaoOuAtribuicao(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitExpressaoOuAtribuicao" ):
                return visitor.visitExpressaoOuAtribuicao(self)
            else:
                return visitor.visitChildren(self)




    def expressaoOuAtribuicao(self):

        localctx = MOCParser.ExpressaoOuAtribuicaoContext(self, self._ctx, self.state)
        self.enterRule(localctx, 78, self.RULE_expressaoOuAtribuicao)
        try:
            self.state = 441
            self._errHandler.sync(self)
            la_ = self._interp.adaptivePredict(self._input,39,self._ctx)
            if la_ == 1:
                self.enterOuterAlt(localctx, 1)
                self.state = 437
                self.match(MOCParser.IDENTIFICADOR)
                self.state = 438
                self.match(MOCParser.ATRIBUICAO)
                self.state = 439
                self.expressao()
                pass

            elif la_ == 2:
                self.enterOuterAlt(localctx, 2)
                self.state = 440
                self.expressao()
                pass


        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class InstrucaoEscritaContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def WRITE(self):
            return self.getToken(MOCParser.WRITE, 0)

        def ABREPAR(self):
            return self.getToken(MOCParser.ABREPAR, 0)

        def expressao(self):
            return self.getTypedRuleContext(MOCParser.ExpressaoContext,0)


        def FECHAPAR(self):
            return self.getToken(MOCParser.FECHAPAR, 0)

        def PONTOVIRG(self):
            return self.getToken(MOCParser.PONTOVIRG, 0)

        def WRITEC(self):
            return self.getToken(MOCParser.WRITEC, 0)

        def WRITEV(self):
            return self.getToken(MOCParser.WRITEV, 0)

        def IDENTIFICADOR(self):
            return self.getToken(MOCParser.IDENTIFICADOR, 0)

        def WRITES(self):
            return self.getToken(MOCParser.WRITES, 0)

        def argumentoString(self):
            return self.getTypedRuleContext(MOCParser.ArgumentoStringContext,0)


        def getRuleIndex(self):
            return MOCParser.RULE_instrucaoEscrita

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterInstrucaoEscrita" ):
                listener.enterInstrucaoEscrita(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitInstrucaoEscrita" ):
                listener.exitInstrucaoEscrita(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitInstrucaoEscrita" ):
                return visitor.visitInstrucaoEscrita(self)
            else:
                return visitor.visitChildren(self)




    def instrucaoEscrita(self):

        localctx = MOCParser.InstrucaoEscritaContext(self, self._ctx, self.state)
        self.enterRule(localctx, 80, self.RULE_instrucaoEscrita)
        try:
            self.state = 466
            self._errHandler.sync(self)
            token = self._input.LA(1)
            if token in [8]:
                self.enterOuterAlt(localctx, 1)
                self.state = 443
                self.match(MOCParser.WRITE)
                self.state = 444
                self.match(MOCParser.ABREPAR)
                self.state = 445
                self.expressao()
                self.state = 446
                self.match(MOCParser.FECHAPAR)
                self.state = 447
                self.match(MOCParser.PONTOVIRG)
                pass
            elif token in [9]:
                self.enterOuterAlt(localctx, 2)
                self.state = 449
                self.match(MOCParser.WRITEC)
                self.state = 450
                self.match(MOCParser.ABREPAR)
                self.state = 451
                self.expressao()
                self.state = 452
                self.match(MOCParser.FECHAPAR)
                self.state = 453
                self.match(MOCParser.PONTOVIRG)
                pass
            elif token in [10]:
                self.enterOuterAlt(localctx, 3)
                self.state = 455
                self.match(MOCParser.WRITEV)
                self.state = 456
                self.match(MOCParser.ABREPAR)
                self.state = 457
                self.match(MOCParser.IDENTIFICADOR)
                self.state = 458
                self.match(MOCParser.FECHAPAR)
                self.state = 459
                self.match(MOCParser.PONTOVIRG)
                pass
            elif token in [11]:
                self.enterOuterAlt(localctx, 4)
                self.state = 460
                self.match(MOCParser.WRITES)
                self.state = 461
                self.match(MOCParser.ABREPAR)
                self.state = 462
                self.argumentoString()
                self.state = 463
                self.match(MOCParser.FECHAPAR)
                self.state = 464
                self.match(MOCParser.PONTOVIRG)
                pass
            else:
                raise NoViableAltException(self)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class InstrucaoReturnContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def RETURN(self):
            return self.getToken(MOCParser.RETURN, 0)

        def expressao(self):
            return self.getTypedRuleContext(MOCParser.ExpressaoContext,0)


        def PONTOVIRG(self):
            return self.getToken(MOCParser.PONTOVIRG, 0)

        def getRuleIndex(self):
            return MOCParser.RULE_instrucaoReturn

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterInstrucaoReturn" ):
                listener.enterInstrucaoReturn(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitInstrucaoReturn" ):
                listener.exitInstrucaoReturn(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitInstrucaoReturn" ):
                return visitor.visitInstrucaoReturn(self)
            else:
                return visitor.visitChildren(self)




    def instrucaoReturn(self):

        localctx = MOCParser.InstrucaoReturnContext(self, self._ctx, self.state)
        self.enterRule(localctx, 82, self.RULE_instrucaoReturn)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 468
            self.match(MOCParser.RETURN)
            self.state = 469
            self.expressao()
            self.state = 470
            self.match(MOCParser.PONTOVIRG)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class InstrucaoAtribuicaoContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def ATRIBUICAO(self):
            return self.getToken(MOCParser.ATRIBUICAO, 0)

        def expressao(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(MOCParser.ExpressaoContext)
            else:
                return self.getTypedRuleContext(MOCParser.ExpressaoContext,i)


        def PONTOVIRG(self):
            return self.getToken(MOCParser.PONTOVIRG, 0)

        def IDENTIFICADOR(self):
            return self.getToken(MOCParser.IDENTIFICADOR, 0)

        def ABRECOLCH(self):
            return self.getToken(MOCParser.ABRECOLCH, 0)

        def FECHACOLCH(self):
            return self.getToken(MOCParser.FECHACOLCH, 0)

        def getRuleIndex(self):
            return MOCParser.RULE_instrucaoAtribuicao

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterInstrucaoAtribuicao" ):
                listener.enterInstrucaoAtribuicao(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitInstrucaoAtribuicao" ):
                listener.exitInstrucaoAtribuicao(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitInstrucaoAtribuicao" ):
                return visitor.visitInstrucaoAtribuicao(self)
            else:
                return visitor.visitChildren(self)




    def instrucaoAtribuicao(self):

        localctx = MOCParser.InstrucaoAtribuicaoContext(self, self._ctx, self.state)
        self.enterRule(localctx, 84, self.RULE_instrucaoAtribuicao)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 478
            self._errHandler.sync(self)
            la_ = self._interp.adaptivePredict(self._input,41,self._ctx)
            if la_ == 1:
                self.state = 472
                self.match(MOCParser.IDENTIFICADOR)
                pass

            elif la_ == 2:
                self.state = 473
                self.match(MOCParser.IDENTIFICADOR)
                self.state = 474
                self.match(MOCParser.ABRECOLCH)
                self.state = 475
                self.expressao()
                self.state = 476
                self.match(MOCParser.FECHACOLCH)
                pass


            self.state = 480
            self.match(MOCParser.ATRIBUICAO)
            self.state = 481
            self.expressao()
            self.state = 482
            self.match(MOCParser.PONTOVIRG)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class ArgumentoStringContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def IDENTIFICADOR(self):
            return self.getToken(MOCParser.IDENTIFICADOR, 0)

        def STRINGLITERAL(self):
            return self.getToken(MOCParser.STRINGLITERAL, 0)

        def getRuleIndex(self):
            return MOCParser.RULE_argumentoString

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterArgumentoString" ):
                listener.enterArgumentoString(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitArgumentoString" ):
                listener.exitArgumentoString(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitArgumentoString" ):
                return visitor.visitArgumentoString(self)
            else:
                return visitor.visitChildren(self)




    def argumentoString(self):

        localctx = MOCParser.ArgumentoStringContext(self, self._ctx, self.state)
        self.enterRule(localctx, 86, self.RULE_argumentoString)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 484
            _la = self._input.LA(1)
            if not(_la==40 or _la==45):
                self._errHandler.recoverInline(self)
            else:
                self._errHandler.reportMatch(self)
                self.consume()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx



    def sempred(self, localctx:RuleContext, ruleIndex:int, predIndex:int):
        if self._predicates == None:
            self._predicates = dict()
        self._predicates[17] = self.expressaoOr_sempred
        self._predicates[18] = self.expressaoAnd_sempred
        self._predicates[20] = self.expressaoAdd_sempred
        self._predicates[21] = self.expressaoMul_sempred
        pred = self._predicates.get(ruleIndex, None)
        if pred is None:
            raise Exception("No predicate with index:" + str(ruleIndex))
        else:
            return pred(localctx, predIndex)

    def expressaoOr_sempred(self, localctx:ExpressaoOrContext, predIndex:int):
            if predIndex == 0:
                return self.precpred(self._ctx, 2)
         

    def expressaoAnd_sempred(self, localctx:ExpressaoAndContext, predIndex:int):
            if predIndex == 1:
                return self.precpred(self._ctx, 2)
         

    def expressaoAdd_sempred(self, localctx:ExpressaoAddContext, predIndex:int):
            if predIndex == 2:
                return self.precpred(self._ctx, 3)
         

            if predIndex == 3:
                return self.precpred(self._ctx, 2)
         

    def expressaoMul_sempred(self, localctx:ExpressaoMulContext, predIndex:int):
            if predIndex == 4:
                return self.precpred(self._ctx, 4)
         

            if predIndex == 5:
                return self.precpred(self._ctx, 3)
         

            if predIndex == 6:
                return self.precpred(self._ctx, 2)
         




